"""Карточки, жеребьёвка и итоги по доскам в книге Excel."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from excel_io import Cell, Workbook
from model import BYE_LABELS, PLAYED, RESULT_LABELS, Tournament, sex_label
from teams import BYE_MATCH_POINTS, TeamTournament, _game_points, _match_of, _match_points, _match_ready

PRINT_NOTE = "Для печати откройте файл в Excel: Файл → Печать. Страница уже альбомная, формат A4."


@dataclass
class GameView:
    round_no: int
    board: int | None
    color: str
    opponent: str
    opponent_rating: int | None
    opponent_group: str
    result: str
    points: float | None
    match_score: str = ""
    match_points: int | None = None


@dataclass
class Person:
    group: str
    name: str
    sex: str
    age: int | None
    rating: int
    sheet_title: str
    sheet_name: str = ""
    games: list[GameView] = field(default_factory=list)

    @property
    def points(self) -> float:
        return sum(game.points or 0 for game in self.games)

    @property
    def played(self) -> int:
        return sum(game.points is not None and game.board is not None for game in self.games)


@dataclass
class BoardRow:
    round_no: int
    match_no: int | None
    board: int
    white_name: str
    white_sex: str
    white_age: int | None
    white_rating: int | None
    white_group: str
    black_name: str
    black_sex: str
    black_age: int | None
    black_rating: int | None
    black_group: str
    result: str
    white_points: float | None
    black_points: float | None
    result_code: str | None = None
    white_number: int | None = None
    black_number: int | None = None


def write_players(tournament, path: Path) -> None:
    players_workbook(tournament).save(path)


def write_teams(tournament, path: Path) -> None:
    teams_workbook(tournament).save(path)


def write_pairing(tournament, path: Path, round_indexes: list[int] | None = None) -> None:
    pairing_workbook(tournament, round_indexes).save(path)


def write_boards(tournament, path: Path) -> None:
    boards_workbook(tournament).save(path)


def players_workbook(tournament) -> Workbook:
    people = collect_people(tournament)
    if not people:
        raise ValueError("В турнире пока нет игроков.")
    book = Workbook()
    index = book.add("Игроки", [22, 24, 28, 8, 12, 12, 12, 12], True)
    widths = [8, 10, 14, 28, 12, 24, 12, 14, 14]
    for person in people:
        sheet = book.add(person.sheet_title, widths)
        person.sheet_name = sheet.name
        _person_sheet(sheet, tournament.name, person)
    _people_index(index, tournament, people)
    return book


def teams_workbook(tournament) -> Workbook:
    if not isinstance(tournament, TeamTournament):
        raise ValueError("Карточки команд есть только в командном турнире.")
    if not tournament.teams:
        raise ValueError("В турнире пока нет команд.")
    book = Workbook()
    index = book.add("Команды", [22, 8, 28, 12, 12, 14, 14, 14], True)
    made: dict[int, str] = {}
    for number, team in enumerate(tournament.teams, start=1):
        sheet = book.add(team.name, [8, 14, 28, 28, 16, 14, 14])
        _team_sheet(sheet, tournament, number)
        made[number] = sheet.name
    _team_index(index, tournament, made)
    return book


def pairing_workbook(tournament, round_indexes: list[int] | None = None) -> Workbook:
    if not tournament.rounds_played:
        raise ValueError("Сначала сделайте жеребьёвку тура.")
    indexes = list(range(len(tournament.rounds_played))) if round_indexes is None else round_indexes
    book = Workbook()
    for index in indexes:
        if isinstance(tournament, TeamTournament):
            sheet = book.add(f"Тур {index + 1}", [8, 26, 6, 8, 9, 18, 12, 26, 6, 8, 9, 18])
            _team_pairing_sheet(sheet, tournament, index)
        else:
            sheet = book.add(f"Тур {index + 1}", [8, 6, 24, 6, 8, 9, 16, 12, 6, 24, 6, 8, 9, 16])
            _individual_pairing_sheet(sheet, tournament, index)
    return book


def boards_workbook(tournament) -> Workbook:
    rows = collect_boards(tournament)
    if not tournament.rounds_played:
        raise ValueError("Сначала сделайте жеребьёвку тура.")
    group = "Команда" if isinstance(tournament, TeamTournament) else "Клуб"
    book = Workbook()
    summary = book.add("Сводка", [10, 28, 8, 12, 22, 12, 12, 12, 12, 12, 14])
    _board_summary(summary, tournament.name, rows, group)
    boards = tournament.boards if isinstance(tournament, TeamTournament) else _max_board(rows)
    team_mode = isinstance(tournament, TeamTournament)
    for board in range(1, boards + 1):
        widths = [8, 10, 26, 6, 8, 9, 18, 12, 26, 6, 8, 9, 18] if team_mode else [8, 26, 6, 8, 9, 18, 12, 26, 6, 8, 9, 18]
        sheet = book.add(f"Доска {board}", widths)
        _one_board_sheet(sheet, tournament.name, board, [row for row in rows if row.board == board], group, team_mode)
    return book


def collect_people(tournament) -> list[Person]:
    if isinstance(tournament, TeamTournament):
        return _team_people(tournament)
    return _individual_people(tournament)


def collect_boards(tournament) -> list[BoardRow]:
    if isinstance(tournament, TeamTournament):
        return _team_boards(tournament)
    return _individual_boards(tournament)


def _individual_people(tournament: Tournament) -> list[Person]:
    people = [
        Person(
            group=player.club,
            name=player.name,
            sex=sex_label(player.sex),
            age=player.age,
            rating=player.rating,
            sheet_title=player.name or f"Игрок {number}",
        )
        for number, player in enumerate(tournament.players, start=1)
    ]
    by_number = {number: person for number, person in enumerate(people, start=1)}
    for row in _individual_boards(tournament):
        _append_individual(by_number, row, True)
        _append_individual(by_number, row, False)
    for round_no, games in enumerate(tournament.rounds_played, start=1):
        for game in games:
            if not game.is_bye:
                continue
            person = by_number.get(game.white)
            if person is None:
                continue
            person.games.append(
                GameView(round_no, None, "—", "бай", None, "", BYE_LABELS.get(game.result or "", "бай"), _bye_points(game.result))
            )
    for person in people:
        person.games.sort(key=lambda item: (item.round_no, item.board or 0))
    return people


def _team_people(tournament: TeamTournament) -> list[Person]:
    people: list[Person] = []
    index: dict[tuple[int, str], Person] = {}
    for number, team in enumerate(tournament.teams, start=1):
        seen: set[str] = set()
        names = [member.name.strip() for member in team.members if member.name.strip()]
        for matches in tournament.rounds_played:
            match = _match_of(matches, number)
            if match is None or match.is_bye:
                continue
            for board_index, board in enumerate(match.boards):
                own = _side_name(board, _team_is_white(match, number, board_index))
                if own:
                    names.append(own)
        for name in names:
            key = name.casefold()
            if key in seen:
                continue
            seen.add(key)
            member = _find_member(team, name)
            person = Person(
                group=team.name,
                name=name,
                sex=sex_label(member.sex) if member else "",
                age=member.age if member else None,
                rating=member.rating if member else 0,
                sheet_title=f"{team.name} {name}",
            )
            people.append(person)
            index[(number, key)] = person
    for round_no, matches in enumerate(tournament.rounds_played, start=1):
        for number, team in enumerate(tournament.teams, start=1):
            match = _match_of(matches, number)
            if match is None or not match.is_bye or match.white != number:
                continue
            label = BYE_LABELS.get(match.bye or "", "бай")
            for member in team.members:
                person = index.get((number, member.name.strip().casefold()))
                if person is None:
                    continue
                person.games.append(GameView(round_no, None, "—", "команда не играла", None, "", label, None))
    attach_team_games(people, tournament)
    for person in people:
        person.games.sort(key=lambda item: (item.round_no, item.board or 0))
    return [person for person in people if person.name]


def _append_individual(people: dict[int, Person], row: BoardRow, white: bool) -> None:
    number = row.white_number if white else row.black_number
    if number is None:
        return
    person = people.get(number)
    if person is None:
        return
    opponent_rating = row.black_rating if white else row.white_rating
    person.games.append(
        GameView(
            row.round_no,
            row.board,
            "Белые" if white else "Чёрные",
            row.black_name if white else row.white_name,
            opponent_rating,
            row.black_group if white else row.white_group,
            _own_result(row, white),
            row.white_points if white else row.black_points,
        )
    )


def _individual_boards(tournament: Tournament) -> list[BoardRow]:
    rows: list[BoardRow] = []
    for round_no, games in enumerate(tournament.rounds_played, start=1):
        board_no = 0
        for game in games:
            if game.is_bye or game.black is None:
                continue
            board_no += 1
            white = tournament.player(game.white)
            black = tournament.player(game.black)
            white_points, black_points = _both_points(game.result)
            row = BoardRow(
                round_no,
                None,
                board_no,
                white.name,
                sex_label(white.sex),
                white.age,
                white.rating,
                white.club,
                black.name,
                sex_label(black.sex),
                black.age,
                black.rating,
                black.club,
                RESULT_LABELS.get(game.result or "", ""),
                white_points,
                black_points,
                game.result,
                game.white,
                game.black,
            )
            rows.append(row)
    return rows


def _team_boards(tournament: TeamTournament) -> list[BoardRow]:
    rows: list[BoardRow] = []
    for round_no, matches in enumerate(tournament.rounds_played, start=1):
        for match_no, match in enumerate(matches, start=1):
            if match.is_bye:
                continue
            for board_index, board in enumerate(match.boards):
                white_team_no = match.white if board_index % 2 == 0 else match.black
                black_team_no = match.black if board_index % 2 == 0 else match.white
                assert white_team_no is not None and black_team_no is not None
                white_team = tournament.team(white_team_no)
                black_team = tournament.team(black_team_no)
                white_member = _find_member(white_team, board.white_name)
                black_member = _find_member(black_team, board.black_name)
                white_points, black_points = _both_points(board.result)
                rows.append(
                    BoardRow(
                        round_no,
                        match_no,
                        board_index + 1,
                        board.white_name.strip() or "без игрока",
                        sex_label(white_member.sex) if white_member else "",
                        white_member.age if white_member else None,
                        white_member.rating if white_member else None,
                        white_team.name,
                        board.black_name.strip() or "без игрока",
                        sex_label(black_member.sex) if black_member else "",
                        black_member.age if black_member else None,
                        black_member.rating if black_member else None,
                        black_team.name,
                        RESULT_LABELS.get(board.result or "", ""),
                        white_points,
                        black_points,
                        board.result,
                    )
                )
    return rows


def _person_sheet(sheet, tournament_name: str, person: Person) -> None:
    _title(sheet, tournament_name)
    bits = [f"Игрок: {person.name}"]
    if person.group:
        bits.append(f"Команда/клуб: {person.group}")
    if person.sex:
        bits.append(f"Пол: {person.sex}")
    if person.age is not None:
        bits.append(f"Возраст: {person.age}")
    if person.rating:
        bits.append(f"Рейтинг: {person.rating}")
    bits.append(f"Очки: {_trim(person.points)}")
    _subtitle(sheet, " · ".join(bits))
    sheet.add([Cell(None, "gap")])
    headers = ["Тур", "Доска", "Цвет", "Соперник", "Рейтинг", "Команда/клуб", "Результат", "Очки", "Всего"]
    sheet.add([Cell(text, "header") for text in headers], 24)
    running = 0.0
    if not person.games:
        sheet.add([Cell("Партий пока нет", "text")] + [Cell(None, "text") for _ in range(8)])
        sheet.merge(len(sheet.rows) - 1, 0, len(sheet.widths) - 1)
        return
    for game in person.games:
        if game.points is not None:
            running += game.points
        style = "zebra" if game.round_no % 2 == 0 else "text"
        center = "center"
        sheet.add(
            [
                Cell(game.round_no, center),
                Cell("" if game.board is None else game.board, center),
                Cell(game.color, center),
                Cell(game.opponent, style),
                Cell("" if not game.opponent_rating else game.opponent_rating, center),
                Cell(game.opponent_group, style),
                Cell(game.result, "points"),
                Cell("" if game.points is None else game.points, center),
                Cell(running, center),
            ]
        )


def _people_index(sheet, tournament, people: list[Person]) -> None:
    _title(sheet, tournament.name)
    _subtitle(sheet, "Карточка каждого игрока — на отдельном листе. " + PRINT_NOTE)
    sheet.add([Cell(None, "gap")])
    headers = ["Лист", "Команда/клуб", "Игрок", "Пол", "Возраст", "Рейтинг", "Партий", "Очки"]
    sheet.add([Cell(text, "header") for text in headers], 24)
    for person in people:
        sheet.add(
            [
                Cell(person.sheet_name, "link", person.sheet_name),
                Cell(person.group, "text"),
                Cell(person.name, "text"),
                Cell(person.sex, "center"),
                Cell("" if person.age is None else person.age, "center"),
                Cell(person.rating or "", "center"),
                Cell(person.played, "center"),
                Cell(person.points, "center"),
            ]
        )


def _team_sheet(sheet, tournament: TeamTournament, number: int) -> None:
    team = tournament.team(number)
    standing = next(row for row in tournament.standings() if row["number"] == number)
    _title(sheet, tournament.name)
    _subtitle(
        sheet,
        f"Команда: {team.name} · Место {standing['place']} · Матчевые {standing['points']} · "
        f"Игровые {_trim(standing['game_points'])} · Бухгольц {_trim(standing['buchholz'])}",
    )
    roster = []
    for index, member in enumerate(team.members, start=1):
        bits = [f"{index}. {member.name}"]
        if member.rating:
            bits.append(str(member.rating))
        if sex_label(member.sex):
            bits.append(sex_label(member.sex))
        if member.age is not None:
            bits.append(f"{member.age} лет")
        roster.append(" ".join(bits))
    _subtitle(sheet, "Состав: " + (", ".join(roster) if roster else "не внесён"))
    sheet.add([Cell(None, "gap")])
    _subtitle(sheet, "Матчи")
    sheet.add([Cell(text, "header") for text in ("Тур", "Цвет", "Соперник", "Счёт", "Матч. очки", "Игровые", "")], 24)
    for round_no, matches in enumerate(tournament.rounds_played, start=1):
        match = _match_of(matches, number)
        if match is None:
            continue
        if match.is_bye and match.white == number:
            sheet.add(
                [
                    Cell(round_no, "center"),
                    Cell("—", "center"),
                    Cell(BYE_LABELS.get(match.bye or "", "бай"), "text"),
                    Cell("—", "center"),
                    Cell(BYE_MATCH_POINTS.get(match.bye or "Z", 0), "center"),
                    Cell(_bye_game_points(match.bye, tournament.boards), "center"),
                    Cell(None, "gap"),
                ]
            )
            continue
        if match.is_bye or match.black is None:
            continue
        opponent = match.black if match.white == number else match.white
        ready = _match_ready(match)
        ours = _game_points(match, number, tournament.boards) if ready else None
        theirs = _game_points(match, opponent, tournament.boards) if ready else None
        sheet.add(
            [
                Cell(round_no, "center"),
                Cell("Белые" if match.white == number else "Чёрные", "center"),
                Cell(tournament.team(opponent).name, "text"),
                Cell("…" if ours is None or theirs is None else f"{_trim(ours)}–{_trim(theirs)}", "points"),
                Cell("" if not ready else _match_points(match, number), "center"),
                Cell("" if ours is None else ours, "center"),
                Cell(None, "gap"),
            ]
        )
    sheet.add([Cell(None, "gap")])
    _subtitle(sheet, "Партии по доскам")
    detail = book_headers = ("Тур", "Доска", "Наш игрок", "Цвет", "Соперник", "Результат", "Счёт матча")
    del book_headers
    sheet.add([Cell(text, "header") for text in detail], 24)
    for round_no, matches in enumerate(tournament.rounds_played, start=1):
        match = _match_of(matches, number)
        if match is None or match.is_bye or match.black is None:
            continue
        opponent = match.black if match.white == number else match.white
        ready = _match_ready(match)
        ours = _game_points(match, number, tournament.boards) if ready else None
        theirs = _game_points(match, opponent, tournament.boards) if ready else None
        score = "" if ours is None or theirs is None else f"{_trim(ours)}–{_trim(theirs)}"
        for board_index, board in enumerate(match.boards):
            is_white = _team_is_white(match, number, board_index)
            own = _side_name(board, is_white) or "без игрока"
            other = _side_name(board, not is_white) or "без игрока"
            result, _points = _outcome(board.result, is_white)
            style = "zebra" if board_index % 2 else "text"
            sheet.add(
                [
                    Cell(round_no, "center"),
                    Cell(board_index + 1, "center"),
                    Cell(own, style),
                    Cell("Белые" if is_white else "Чёрные", "center"),
                    Cell(other, style),
                    Cell(result, "points"),
                    Cell(score, "center"),
                ]
            )


def _team_index(sheet, tournament: TeamTournament, names: dict[int, str]) -> None:
    _title(sheet, tournament.name)
    _subtitle(sheet, "Карточка каждой команды — на отдельном листе. " + PRINT_NOTE)
    sheet.add([Cell(None, "gap")])
    headers = ["Лист", "№", "Команда", "Место", "Матч", "Игры", "Бухгольц", "Зоннеборн"]
    sheet.add([Cell(text, "header") for text in headers], 24)
    order = {row["number"]: row for row in tournament.standings()}
    for number, team in enumerate(tournament.teams, start=1):
        row = order[number]
        sheet_name = names[number]
        sheet.add(
            [
                Cell(sheet_name, "link", sheet_name),
                Cell(number, "center"),
                Cell(team.name, "text"),
                Cell(row["place"], "center"),
                Cell(row["points"], "center"),
                Cell(row["game_points"], "center"),
                Cell(row["buchholz"], "center"),
                Cell(row["sonneborn"], "center"),
            ]
        )


def _individual_pairing_sheet(sheet, tournament: Tournament, index: int) -> None:
    _title(sheet, tournament.name)
    _subtitle(sheet, f"Жеребьёвка. Тур {index + 1} из {tournament.rounds}. {PRINT_NOTE}")
    sheet.add([Cell("Дата ______________      Судья ______________", "subtitle")])
    sheet.merge(len(sheet.rows) - 1, 0, len(sheet.widths) - 1)
    headers = ["Доска", "№", "Белые", "Пол", "Возраст", "Рейтинг", "Клуб", "Результат", "№", "Чёрные", "Пол", "Возраст", "Рейтинг", "Клуб"]
    sheet.add([Cell(text, "header") for text in headers], 26)
    board = 0
    byes: list[str] = []
    for game in tournament.rounds_played[index]:
        if game.is_bye:
            byes.append(f"{tournament.player(game.white).name} — {BYE_LABELS.get(game.result or '', 'бай')}")
            continue
        assert game.black is not None
        board += 1
        white = tournament.player(game.white)
        black = tournament.player(game.black)
        result = RESULT_LABELS.get(game.result or "", "")
        sheet.add(
            [
                Cell(board, "center"),
                Cell(game.white, "center"),
                Cell(white.name, "text"),
                Cell(sex_label(white.sex), "center"),
                Cell("" if white.age is None else white.age, "center"),
                Cell(white.rating or "", "center"),
                Cell(white.club, "text"),
                Cell(result, "points"),
                Cell(game.black, "center"),
                Cell(black.name, "text"),
                Cell(sex_label(black.sex), "center"),
                Cell("" if black.age is None else black.age, "center"),
                Cell(black.rating or "", "center"),
                Cell(black.club, "text"),
            ],
            22,
        )
    if byes:
        sheet.add([Cell(None, "gap")])
        _subtitle(sheet, "Не играют: " + "; ".join(byes))


def _team_pairing_sheet(sheet, tournament: TeamTournament, index: int) -> None:
    _title(sheet, tournament.name)
    _subtitle(sheet, f"Жеребьёвка. Тур {index + 1} из {tournament.rounds}. Цвета внутри матча чередуются. {PRINT_NOTE}")
    sheet.add([Cell("Дата ______________      Судья ______________", "subtitle")])
    sheet.merge(len(sheet.rows) - 1, 0, len(sheet.widths) - 1)
    headers = ["Доска", "Белые", "Пол", "Возраст", "Рейтинг", "Команда", "Результат", "Чёрные", "Пол", "Возраст", "Рейтинг", "Команда"]
    byes: list[str] = []
    first_match = True
    for match_no, match in enumerate(tournament.rounds_played[index], start=1):
        if match.is_bye:
            byes.append(f"{tournament.team(match.white).name} — {BYE_LABELS.get(match.bye or '', 'бай')}")
            continue
        assert match.black is not None
        if not first_match:
            sheet.add([Cell(None, "gap")], 10)
        first_match = False
        ready = _match_ready(match)
        score = ""
        if ready:
            white_points = _game_points(match, match.white, tournament.boards)
            black_points = _game_points(match, match.black, tournament.boards)
            score = f"    {_trim(white_points)}–{_trim(black_points)}"
        sheet.add(
            [Cell(f"Матч {match_no}. {tournament.team(match.white).name} — {tournament.team(match.black).name}{score}", "section")]
        )
        sheet.merge(len(sheet.rows) - 1, 0, len(sheet.widths) - 1)
        sheet.add([Cell(text, "header") for text in headers], 22)
        for board_index, board in enumerate(match.boards):
            white_team = tournament.team(match.white if board_index % 2 == 0 else match.black)
            black_team = tournament.team(match.black if board_index % 2 == 0 else match.white)
            white_member = _find_member(white_team, board.white_name)
            black_member = _find_member(black_team, board.black_name)
            sheet.add(
                [
                    Cell(board_index + 1, "center"),
                    Cell(board.white_name.strip() or "без игрока", "text"),
                    Cell(sex_label(white_member.sex) if white_member else "", "center"),
                    Cell("" if white_member is None or white_member.age is None else white_member.age, "center"),
                    Cell("" if white_member is None or not white_member.rating else white_member.rating, "center"),
                    Cell(white_team.name, "text"),
                    Cell(RESULT_LABELS.get(board.result or "", ""), "points"),
                    Cell(board.black_name.strip() or "без игрока", "text"),
                    Cell(sex_label(black_member.sex) if black_member else "", "center"),
                    Cell("" if black_member is None or black_member.age is None else black_member.age, "center"),
                    Cell("" if black_member is None or not black_member.rating else black_member.rating, "center"),
                    Cell(black_team.name, "text"),
                ],
                22,
            )
    if byes:
        sheet.add([Cell(None, "gap")])
        _subtitle(sheet, "Не играют: " + "; ".join(byes))


def _board_summary(sheet, tournament_name: str, rows: list[BoardRow], group_title: str) -> None:
    _title(sheet, tournament_name)
    _subtitle(sheet, "Кто сколько набрал на каждой доске. Подробные партии — на листах досок. " + PRINT_NOTE)
    sheet.add([Cell(None, "gap")])
    headers = ["Доска", "Игрок", "Пол", "Возраст", "Команда" if group_title == "Команда" else group_title, "Рейтинг", "Партий", "Очки", "Победы", "Ничьи", "Поражения"]
    sheet.add([Cell(text, "header") for text in headers], 24)
    totals: dict[tuple, dict] = {}
    for row in rows:
        for white in (True, False):
            name = row.white_name if white else row.black_name
            if not name or name == "без игрока":
                continue
            key = (row.board, row.white_group if white else row.black_group, name.casefold())
            item = totals.setdefault(
                key,
                {
                    "board": row.board,
                    "name": name,
                    "sex": row.white_sex if white else row.black_sex,
                    "age": row.white_age if white else row.black_age,
                    "group": row.white_group if white else row.black_group,
                    "rating": row.white_rating if white else row.black_rating,
                    "games": 0,
                    "points": 0.0,
                    "wins": 0,
                    "draws": 0,
                    "losses": 0,
                },
            )
            points = row.white_points if white else row.black_points
            if points is None:
                continue
            item["games"] += 1
            item["points"] += points
            if points == 1:
                item["wins"] += 1
            elif points == 0.5:
                item["draws"] += 1
            else:
                item["losses"] += 1
    ordered = sorted(totals.values(), key=lambda item: (item["board"], -item["points"], item["name"].casefold()))
    for item in ordered:
        sheet.add(
            [
                Cell(item["board"], "center"),
                Cell(item["name"], "text"),
                Cell(item["sex"], "center"),
                Cell("" if item["age"] is None else item["age"], "center"),
                Cell(item["group"], "text"),
                Cell("" if not item["rating"] else item["rating"], "center"),
                Cell(item["games"], "center"),
                Cell(item["points"], "center"),
                Cell(item["wins"], "center"),
                Cell(item["draws"], "center"),
                Cell(item["losses"], "center"),
            ]
        )
    if not ordered:
        sheet.add([Cell("Партий по доскам пока нет", "text")])


def _one_board_sheet(sheet, tournament_name: str, board: int, rows: list[BoardRow], group_title: str, match_col: bool) -> None:
    _title(sheet, tournament_name)
    _subtitle(sheet, f"Доска {board}. Кто с кем играл и с каким результатом.")
    sheet.add([Cell(None, "gap")])
    headers = ["Тур"]
    if match_col:
        headers.append("Матч")
    headers += ["Белые", "Пол", "Возраст", "Рейтинг", group_title, "Результат", "Чёрные", "Пол", "Возраст", "Рейтинг", group_title]
    # Ширины листа заданы с колонкой матча. Для личного турнира матча нет — сдвигаем в те же колонки.
    sheet.add([Cell(text, "header") for text in headers], 24)
    if not rows:
        sheet.add([Cell("На этой доске партий нет", "text")])
        return
    for row in rows:
        values: list[Cell] = [Cell(row.round_no, "center")]
        if match_col:
            values.append(Cell("" if row.match_no is None else row.match_no, "center"))
        values.extend(
            [
                Cell(row.white_name, "text"),
                Cell(row.white_sex, "center"),
                Cell("" if row.white_age is None else row.white_age, "center"),
                Cell("" if not row.white_rating else row.white_rating, "center"),
                Cell(row.white_group, "text"),
                Cell(row.result, "points"),
                Cell(row.black_name, "text"),
                Cell(row.black_sex, "center"),
                Cell("" if row.black_age is None else row.black_age, "center"),
                Cell("" if not row.black_rating else row.black_rating, "center"),
                Cell(row.black_group, "text"),
            ]
        )
        sheet.add(values, 22)


def _title(sheet, text: str) -> None:
    sheet.add([Cell(text, "title")], 28)
    sheet.merge(len(sheet.rows) - 1, 0, len(sheet.widths) - 1)


def _subtitle(sheet, text: str, height: float = 34) -> None:
    sheet.add([Cell(text, "subtitle")], height)
    sheet.merge(len(sheet.rows) - 1, 0, len(sheet.widths) - 1)


def _both_points(result: str | None) -> tuple[float | None, float | None]:
    if not result:
        return None, None
    _white, _black, white_halves, black_halves = PLAYED[result]
    return white_halves / 2, black_halves / 2


def _outcome(result: str | None, is_white: bool) -> tuple[str, float | None]:
    if not result:
        return "", None
    white_code, black_code, white_halves, black_halves = PLAYED[result]
    code = white_code if is_white else black_code
    label = {"1": "1", "0": "0", "=": "½", "+": "+", "-": "−"}.get(code, code)
    halves = white_halves if is_white else black_halves
    return label, halves / 2


def _own_result(row: BoardRow, white: bool) -> str:
    return _outcome(row.result_code, white)[0]


def _bye_points(result: str | None) -> float | None:
    if result in {"U", "F"}:
        return 1
    if result == "H":
        return 0.5
    if result == "Z":
        return 0
    return None


def _bye_game_points(bye: str | None, boards: int) -> float:
    if bye in {"U", "F"}:
        return boards / 2
    if bye == "H":
        return boards / 4
    return 0


def _team_is_white(match, number: int, board_index: int) -> bool:
    if board_index % 2 == 0:
        return match.white == number
    return match.black == number


def _side_name(board, is_white: bool) -> str:
    return (board.white_name if is_white else board.black_name).strip()


def _find_member(team, name: str):
    folded = (name or "").strip().casefold()
    if not folded:
        return None
    for member in team.members:
        if member.name.strip().casefold() == folded:
            return member
    return None


def _max_board(rows: list[BoardRow]) -> int:
    return max((row.board for row in rows), default=1)


def _trim(value: float) -> str:
    return f"{value:.1f}".rstrip("0").rstrip(".")


def attach_team_games(people: list[Person], tournament: TeamTournament) -> None:
    index = {(person.group.casefold(), person.name.casefold()): person for person in people}
    for row in _team_boards(tournament):
        for white in (True, False):
            name = row.white_name if white else row.black_name
            group = row.white_group if white else row.black_group
            if not name or name == "без игрока":
                continue
            person = index.get((group.casefold(), name.casefold()))
            if person is None:
                continue
            result, points = _outcome(row.result_code, white)
            opponent = row.black_name if white else row.white_name
            person.games.append(
                GameView(
                    row.round_no,
                    row.board,
                    "Белые" if white else "Чёрные",
                    opponent,
                    row.black_rating if white else row.white_rating,
                    row.black_group if white else row.white_group,
                    result,
                    points,
                )
            )


def self_test() -> None:
    import json
    import tempfile
    import zipfile

    sample = Path(__file__).resolve().parent / "командный-8x7.json"
    tournament = TeamTournament.from_dict(json.loads(sample.read_text(encoding="utf-8")))
    people = collect_people(tournament)
    assert len(people) == 24, len(people)
    ivanov = next(person for person in people if person.name.startswith("Иванов"))
    assert ivanov.played == 7, ivanov.played
    assert ivanov.games[0].opponent
    assert ivanov.points == sum(game.points or 0 for game in ivanov.games)
    teams = teams_workbook(tournament)
    assert teams.sheets[0].name == "Команды"
    assert len(teams.sheets) == 9
    pairing = pairing_workbook(tournament)
    assert len(pairing.sheets) == 7
    boards = boards_workbook(tournament)
    assert [sheet.name for sheet in boards.sheets] == ["Сводка", "Доска 1", "Доска 2", "Доска 3"]
    assert any(cell.value == "Иванов А." or (isinstance(cell.value, str) and cell.value.startswith("Иванов")) for row in boards.sheets[1].rows for cell in row)
    personal = Tournament(name="Личный", rounds=1)
    personal.add_player("Альфа", 1800, "Север", 14, "м")
    personal.add_player("Бета", 1500, "Юг", 16, "ж")
    personal.pair_next_round()
    personal.rounds_played[0][0].result = "1/2"
    one = collect_people(personal)
    assert one[0].games[0].result == "½" and one[0].points == 0.5
    assert one[1].games[0].color == "Чёрные"
    board_rows = collect_boards(personal)
    assert board_rows[0].match_no is None and board_rows[0].white_age == 14
    try:
        teams_workbook(personal)
    except ValueError:
        pass
    else:
        raise AssertionError("личный турнир не должен выгружать карточки команд")
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / "игроки.xlsx"
        write_players(tournament, path)
        with zipfile.ZipFile(path) as archive:
            workbook = archive.read("xl/workbook.xml").decode("utf-8")
            first = archive.read("xl/worksheets/sheet1.xml").decode("utf-8")
        assert "Игроки" in workbook
        assert "Иванов" in first
        assert "hyperlink" in first
    print("reports ok")


if __name__ == "__main__":
    self_test()
