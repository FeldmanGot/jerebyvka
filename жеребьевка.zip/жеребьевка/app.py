"""Окно местного турнира: игроки, голландская жеребьёвка, результаты, таблица."""

from __future__ import annotations

import json
import os
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import pairing
import reports
from model import BYE_LABELS, RESULT_LABELS, Tournament, clean_age, clean_sex, round_text, sex_label
from teams import Member, TeamTournament

STATUSES = (
    ("играет", "", False),
    ("бай ½", "H", False),
    ("бай 0", "Z", False),
    ("бай 1", "F", False),
    ("снят", "", True),
)
TEAM_STATUSES = (
    ("играет", "", False),
    ("бай 2", "U", False),
    ("бай 1", "H", False),
    ("ноль", "Z", False),
    ("снята", "", True),
)
RESULT_ORDER = ("1-0", "1/2", "0-1")
INDIVIDUAL_TABLE = (
    ("place", "Место", 58, "center"),
    ("n", "№", 40, "center"),
    ("name", "Игрок", 220, "w"),
    ("points", "Очки", 60, "e"),
    ("buchholz", "Бухгольц", 90, "e"),
    ("buchholz_cut", "Бухг.−1", 80, "e"),
    ("sonneborn", "Зоннеборн", 95, "e"),
    ("wins", "Победы", 70, "e"),
)
TEAM_TABLE = (
    ("place", "Место", 58, "center"),
    ("n", "№", 40, "center"),
    ("name", "Команда", 240, "w"),
    ("points", "Матч", 60, "e"),
    ("game_points", "Игры", 70, "e"),
    ("buchholz", "Бухгольц", 90, "e"),
    ("sonneborn", "Зоннеборн", 95, "e"),
)


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Жеребьёвка")
        self.geometry("1280x780")
        self.minsize(1040, 660)
        self.tournament = Tournament()
        self.path: Path | None = None
        self.dirty = False
        self.round_index = 0
        self._loading = False
        self._build()
        self._refresh()
        self.protocol("WM_DELETE_WINDOW", self._close)

    def _build(self) -> None:
        self.configure(bg="#f4f1ea")
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", font=("Segoe UI", 11), background="#f4f1ea")
        style.configure("TFrame", background="#f4f1ea")
        style.configure("TLabel", background="#f4f1ea", foreground="#1c2421")
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), foreground="#1e3d34")
        style.configure("Hint.TLabel", foreground="#5c675f", font=("Segoe UI", 10))
        style.configure("Treeview", rowheight=26, font=("Segoe UI", 11))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        style.configure("TButton", padding=(10, 6))
        style.configure("Accent.TButton", background="#1e3d34", foreground="white", padding=(12, 7))
        style.map("Accent.TButton", background=[("active", "#2b5749")])

        top = ttk.Frame(self, padding=(16, 12, 16, 0))
        top.pack(fill="x")
        ttk.Label(top, text="Жеребьёвка", style="Header.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            top,
            text="Голландская система FIDE: личный турнир или команды по доскам. Рейтинг федерации не считается.",
            style="Hint.TLabel",
        ).grid(row=1, column=0, columnspan=8, sticky="w", pady=(0, 8))

        ttk.Label(top, text="Турнир").grid(row=2, column=0, sticky="w")
        self.name_var = tk.StringVar()
        name = ttk.Entry(top, textvariable=self.name_var, width=32)
        name.grid(row=3, column=0, sticky="we", padx=(0, 12))
        name.bind("<KeyRelease>", lambda _event: self._touch_meta())

        ttk.Label(top, text="Туров").grid(row=2, column=1, sticky="w")
        self.rounds_var = tk.IntVar(value=5)
        self.rounds_spin = ttk.Spinbox(top, from_=1, to=30, textvariable=self.rounds_var, width=5, command=self._touch_meta)
        self.rounds_spin.grid(row=3, column=1, sticky="w", padx=(0, 12))
        self.rounds_spin.bind("<KeyRelease>", lambda _event: self._touch_meta())

        ttk.Label(top, text="Цвет номера 1").grid(row=2, column=2, sticky="w")
        self.color_var = tk.StringVar(value="Белые")
        self.color_box = ttk.Combobox(top, textvariable=self.color_var, values=("Белые", "Чёрные"), width=10, state="readonly")
        self.color_box.grid(row=3, column=2, sticky="w", padx=(0, 12))
        self.color_box.bind("<<ComboboxSelected>>", lambda _event: self._touch_meta())

        self.baku_var = tk.BooleanVar(value=False)
        self.baku_check = ttk.Checkbutton(top, text="Баку", variable=self.baku_var, command=self._touch_meta)
        self.baku_check.grid(row=3, column=3, sticky="w", padx=(0, 8))

        ttk.Label(top, text="Тип").grid(row=2, column=4, sticky="w")
        self.kind_var = tk.StringVar(value="Личный")
        self.kind_box = ttk.Combobox(top, textvariable=self.kind_var, values=("Личный", "Командный"), width=12, state="readonly")
        self.kind_box.grid(row=3, column=4, sticky="w", padx=(0, 8))
        self.kind_box.bind("<<ComboboxSelected>>", lambda _event: self._change_kind())

        ttk.Label(top, text="Досок").grid(row=2, column=5, sticky="w")
        self.boards_var = tk.IntVar(value=4)
        self.boards_spin = ttk.Spinbox(top, from_=1, to=12, textvariable=self.boards_var, width=4, command=self._touch_meta)
        self.boards_spin.grid(row=3, column=5, sticky="w", padx=(0, 8))

        self.avoid_var = tk.BooleanVar(value=True)
        self.avoid_check = ttk.Checkbutton(top, text="Не сводить один клуб", variable=self.avoid_var, command=self._touch_meta)
        self.avoid_check.grid(row=3, column=6, sticky="w", padx=(0, 8))

        buttons = ttk.Frame(top)
        buttons.grid(row=3, column=7, sticky="e")
        ttk.Button(buttons, text="Новый", command=self._new).pack(side="left", padx=3)
        ttk.Button(buttons, text="Открыть", command=self._open).pack(side="left", padx=3)
        ttk.Button(buttons, text="Сохранить", command=self._save).pack(side="left", padx=3)
        top.columnconfigure(0, weight=1)

        body = ttk.Frame(self, padding=16)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=4)
        body.columnconfigure(1, weight=6)
        body.rowconfigure(0, weight=3)
        body.rowconfigure(1, weight=2)

        self.players_frame = ttk.LabelFrame(body, text="Игроки", padding=8)
        self.players_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        players = self.players_frame
        add = ttk.Frame(players)
        add.pack(fill="x", pady=(0, 8))
        self.player_name = tk.StringVar()
        self.player_rating = tk.StringVar()
        self.player_age = tk.StringVar()
        self.player_sex = tk.StringVar()
        self.club_var = tk.StringVar()
        name_entry = ttk.Entry(add, textvariable=self.player_name)
        name_entry.pack(side="left", fill="x", expand=True)
        name_entry.bind("<Return>", lambda _event: self._add_player())
        self.rating_entry = ttk.Entry(add, textvariable=self.player_rating, width=7)
        self.rating_entry.pack(side="left", padx=6)
        self.rating_entry.bind("<Return>", lambda _event: self._add_player())
        self.age_entry = ttk.Entry(add, textvariable=self.player_age, width=4)
        self.age_entry.pack(side="left", padx=(0, 4))
        self.age_entry.bind("<Return>", lambda _event: self._add_player())
        self.sex_box = ttk.Combobox(add, textvariable=self.player_sex, values=("", "м", "ж"), width=3, state="readonly")
        self.sex_box.pack(side="left", padx=(0, 4))
        self.club_entry = ttk.Entry(add, textvariable=self.club_var, width=12)
        self.club_entry.pack(side="left", padx=(0, 6))
        self.club_entry.bind("<Return>", lambda _event: self._add_player())
        self.add_button = ttk.Button(add, text="Добавить", command=self._add_player)
        self.add_button.pack(side="left")

        self.players_tree = ttk.Treeview(
            players,
            columns=("n", "name", "sex", "age", "club", "rating", "points", "next"),
            show="headings",
            height=12,
        )
        for key, title, width, anchor in (
            ("n", "№", 36, "center"),
            ("name", "Игрок", 140, "w"),
            ("sex", "Пол", 40, "center"),
            ("age", "Возраст", 64, "center"),
            ("club", "Клуб", 80, "w"),
            ("rating", "Рейт.", 55, "e"),
            ("points", "Очки", 50, "e"),
            ("next", "Дальше", 72, "w"),
        ):
            self.players_tree.heading(key, text=title)
            self.players_tree.column(key, width=width, anchor=anchor)
        self.players_tree.pack(fill="both", expand=True)
        self.players_tree.bind("<<TreeviewSelect>>", lambda _event: self._sync_status_box())
        self.players_tree.bind("<Double-1>", lambda _event: self._edit_selected())

        status_row = ttk.Frame(players)
        status_row.pack(fill="x", pady=(8, 0))
        ttk.Label(status_row, text="Дальше").pack(side="left")
        self.status_var = tk.StringVar(value="играет")
        self.status_box = ttk.Combobox(status_row, textvariable=self.status_var, values=[item[0] for item in STATUSES], width=12, state="readonly")
        self.status_box.pack(side="left", padx=6)
        self.status_box.bind("<<ComboboxSelected>>", lambda _event: self._apply_status())
        ttk.Button(status_row, text="Удалить", command=self._remove_player).pack(side="right")
        self.roster_button = ttk.Button(status_row, text="Состав", command=self._edit_roster)
        self.roster_button.pack(side="right", padx=6)
        ttk.Button(status_row, text="Список", command=self._paste_players).pack(side="right")
        self.players_hint = ttk.Label(players, text="", style="Hint.TLabel")
        self.players_hint.pack(anchor="w", pady=(6, 0))

        pairing_frame = ttk.LabelFrame(body, text="Тур", padding=8)
        pairing_frame.grid(row=0, column=1, sticky="nsew")
        round_row = ttk.Frame(pairing_frame)
        round_row.pack(fill="x", pady=(0, 8))
        ttk.Button(round_row, text="←", width=3, command=lambda: self._shift_round(-1)).pack(side="left")
        self.round_label = ttk.Label(round_row, text="Тур не создан")
        self.round_label.pack(side="left", padx=8)
        ttk.Button(round_row, text="→", width=3, command=lambda: self._shift_round(1)).pack(side="left")
        ttk.Button(round_row, text="Жеребить", style="Accent.TButton", command=self._pair).pack(side="right")
        ttk.Button(round_row, text="Удалить тур", command=self._delete_round).pack(side="right", padx=6)
        ttk.Button(round_row, text="Текст", command=self._export).pack(side="right")
        excel = ttk.Menubutton(round_row, text="Excel")
        excel_menu = tk.Menu(excel, tearoff=0)
        excel_menu.add_command(label="Игроки: кто с кем", command=self._excel_players)
        excel_menu.add_command(label="Команды: кто с кем", command=self._excel_teams)
        excel_menu.add_command(label="Жеребьёвка для печати", command=self._excel_pairing)
        excel_menu.add_command(label="Результаты по доскам", command=self._excel_boards)
        excel["menu"] = excel_menu
        excel.pack(side="right", padx=(0, 6))

        self.games_tree = ttk.Treeview(pairing_frame, columns=("board", "white", "black", "result"), show="headings", height=12)
        for key, title, width, anchor in (
            ("board", "Доска", 60, "center"),
            ("white", "Белые", 220, "w"),
            ("black", "Чёрные", 220, "w"),
            ("result", "Результат", 90, "center"),
        ):
            self.games_tree.heading(key, text=title)
            self.games_tree.column(key, width=width, anchor=anchor)
        self.games_tree.pack(fill="both", expand=True)
        self.games_tree.bind("<Double-1>", lambda _event: self._cycle_result())
        self.games_tree.bind("<Key>", self._result_key)

        result_row = ttk.Frame(pairing_frame)
        result_row.pack(fill="x", pady=(8, 0))
        for label, code in (("1–0", "1-0"), ("½–½", "1/2"), ("0–1", "0-1"), ("+/–", "+-"), ("–/+", "-+"), ("0–0", "--")):
            ttk.Button(result_row, text=label, command=lambda code=code: self._set_result(code)).pack(side="left", padx=2)

        table = ttk.LabelFrame(body, text="Таблица", padding=8)
        table.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(8, 0))
        self.table = ttk.Treeview(
            table,
            columns=("place", "n", "name", "rating", "points", "buchholz", "sonneborn"),
            show="headings",
            height=7,
        )
        for key, title, width, anchor in (
            ("place", "Место", 70, "center"),
            ("n", "№", 50, "center"),
            ("name", "Игрок", 280, "w"),
            ("rating", "Рейт.", 70, "e"),
            ("points", "Очки", 70, "e"),
            ("buchholz", "Бухгольц", 100, "e"),
            ("sonneborn", "Зоннеборн", 110, "e"),
        ):
            self.table.heading(key, text=title)
            self.table.column(key, width=width, anchor=anchor, stretch=key == "name")
        self.table.pack(fill="both", expand=True)
        self.table_hint = ttk.Label(table, text="", style="Hint.TLabel")
        self.table_hint.pack(anchor="w", pady=(6, 0))

        self.status = ttk.Label(self, text="", style="Hint.TLabel", padding=(16, 4))
        self.status.pack(fill="x")

    def _mark(self) -> None:
        self.dirty = True
        self.title("Жеребьёвка *")

    def _unmark(self) -> None:
        self.dirty = False
        self.title("Жеребьёвка")

    def _is_team(self) -> bool:
        return self.tournament.kind == "team"

    def _statuses(self) -> tuple:
        return TEAM_STATUSES if self._is_team() else STATUSES

    def _blank(self):
        if self.kind_var.get() == "Командный":
            return TeamTournament(name=self.name_var.get().strip() or "Командный турнир")
        return Tournament(name=self.name_var.get().strip() or "Турнир")

    def _read_meta(self) -> None:
        self.tournament.name = self.name_var.get().strip() or ("Командный турнир" if self._is_team() else "Турнир")
        try:
            rounds = int(self.rounds_var.get())
        except (tk.TclError, ValueError):
            rounds = self.tournament.rounds
        played = len(self.tournament.rounds_played)
        self.tournament.rounds = min(30, max(played or 1, rounds))
        self.tournament.initial_color = "black" if self.color_var.get() == "Чёрные" else "white"
        self.tournament.baku = bool(self.baku_var.get())
        if self._is_team():
            if not self.tournament.started:
                try:
                    boards = int(self.boards_var.get())
                except (tk.TclError, ValueError):
                    boards = self.tournament.boards
                self.tournament.boards = min(12, max(1, boards))
        else:
            self.tournament.avoid_same_club = bool(self.avoid_var.get())

    def _touch_meta(self) -> None:
        if self._loading:
            return
        if self.tournament.started and (
            (self.color_var.get() == "Чёрные") != (self.tournament.initial_color == "black")
            or bool(self.baku_var.get()) != self.tournament.baku
            or (self._is_team() and _safe_int(self.boards_var) != self.tournament.boards)
        ):
            self.color_var.set("Чёрные" if self.tournament.initial_color == "black" else "Белые")
            self.baku_var.set(self.tournament.baku)
            if self._is_team():
                self.boards_var.set(self.tournament.boards)
            messagebox.showinfo("Жеребьёвка", "Цвет номера 1, ускорение Баку и число досок после первого тура уже не меняются.")
            return
        self._read_meta()
        self._mark()
        self._refresh_status()

    def _change_kind(self) -> None:
        if self._loading:
            return
        wanted = "team" if self.kind_var.get() == "Командный" else "individual"
        if wanted == self.tournament.kind:
            return
        if self.tournament.started:
            self.kind_var.set("Командный" if self._is_team() else "Личный")
            messagebox.showinfo("Жеребьёвка", "Тип турнира после первого тура не меняется.")
            return
        has_entries = bool(self.tournament.teams if self._is_team() else self.tournament.players)
        if has_entries and not messagebox.askyesno("Жеребьёвка", "Сменить тип и очистить введённый список?"):
            self.kind_var.set("Командный" if self._is_team() else "Личный")
            return
        name = self.name_var.get().strip()
        rounds = _safe_int(self.rounds_var) or self.tournament.rounds
        self.tournament = TeamTournament(name=name or "Командный турнир", rounds=rounds) if wanted == "team" else Tournament(name=name or "Турнир", rounds=rounds)
        self._mark()
        self._refresh()

    def _selected_player(self) -> int | None:
        selected = self.players_tree.selection()
        if not selected:
            return None
        return int(selected[0])

    def _add_player(self) -> None:
        self._read_meta()
        try:
            if self._is_team():
                self.tournament.add_team(self.player_name.get())
            else:
                rating_text = self.player_rating.get().strip()
                rating = int(rating_text) if rating_text else 0
                self.tournament.add_player(
                    self.player_name.get(),
                    rating,
                    self.club_var.get(),
                    clean_age(self.player_age.get()),
                    clean_sex(self.player_sex.get()),
                )
        except ValueError as error:
            messagebox.showerror("Жеребьёвка", str(error))
            return
        self.player_name.set("")
        self.player_rating.set("")
        self.player_age.set("")
        self.player_sex.set("")
        self.club_var.set("")
        self._mark()
        self._refresh()
        count = len(self.tournament.teams if self._is_team() else self.tournament.players)
        self.players_tree.selection_set(str(count - 1))
        if self._is_team():
            self._edit_roster()

    def _remove_player(self) -> None:
        index = self._selected_player()
        if index is None:
            return
        try:
            if self._is_team():
                self.tournament.remove_team(index)
            else:
                self.tournament.remove_player(index)
        except ValueError as error:
            messagebox.showerror("Жеребьёвка", str(error))
            return
        self._mark()
        self._refresh()

    def _paste_players(self) -> None:
        dialog = tk.Toplevel(self)
        dialog.title("Список")
        dialog.geometry("480x380")
        dialog.transient(self)
        hint = (
            "Команда с новой строки, начинающейся с #. Игрок: Имя 1500    или    Имя 1500 14 м    или    Имя;1500;14;м"
            if self._is_team()
            else "По строке: Имя 1500    или    Имя 1500 14 м    или    Имя;1500;Клуб;14;м"
        )
        ttk.Label(dialog, text=hint).pack(anchor="w", padx=12, pady=(12, 6))
        text = tk.Text(dialog, font=("Segoe UI", 11))
        text.pack(fill="both", expand=True, padx=12)

        def apply() -> None:
            try:
                if self._is_team():
                    _paste_teams(self.tournament, text.get("1.0", "end"))
                else:
                    for raw in text.get("1.0", "end").splitlines():
                        parsed = _parse_player(raw)
                        if parsed is not None:
                            self.tournament.add_player(*parsed)
            except ValueError as error:
                messagebox.showerror("Жеребьёвка", str(error))
                return
            self._mark()
            self._refresh()
            dialog.destroy()

        ttk.Button(dialog, text="Добавить", command=apply).pack(pady=10)

    def _edit_selected(self) -> None:
        if self._is_team():
            self._edit_roster()
        else:
            self._edit_player()

    def _edit_player(self) -> None:
        index = self._selected_player()
        if index is None:
            return
        player = self.tournament.players[index]
        dialog = tk.Toplevel(self)
        dialog.title(player.name or "Игрок")
        dialog.geometry("420x240")
        dialog.transient(self)
        dialog.grab_set()
        form = ttk.Frame(dialog, padding=12)
        form.pack(fill="both", expand=True)
        name = tk.StringVar(value=player.name)
        rating = tk.StringVar(value=str(player.rating or ""))
        club = tk.StringVar(value=player.club)
        age = tk.StringVar(value="" if player.age is None else str(player.age))
        sex = tk.StringVar(value=sex_label(player.sex))
        for row, (label, variable, width) in enumerate(
            (
                ("Имя", name, 28),
                ("Рейтинг", rating, 10),
                ("Возраст", age, 10),
                ("Клуб", club, 28),
            )
        ):
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=4)
            ttk.Entry(form, textvariable=variable, width=width).grid(row=row, column=1, sticky="we", pady=4)
        ttk.Label(form, text="Пол").grid(row=4, column=0, sticky="w", pady=4)
        ttk.Combobox(form, textvariable=sex, values=("", "м", "ж"), width=8, state="readonly").grid(row=4, column=1, sticky="w", pady=4)
        form.columnconfigure(1, weight=1)

        def save() -> None:
            try:
                cleaned = " ".join(name.get().split())
                if not cleaned:
                    raise ValueError("Введите имя.")
                rating_text = rating.get().strip()
                player.rating = int(rating_text) if rating_text else 0
                if player.rating < 0:
                    raise ValueError("Рейтинг не может быть отрицательным.")
                player.name = cleaned
                player.club = " ".join(club.get().split())
                player.age = clean_age(age.get())
                player.sex = clean_sex(sex.get())
            except ValueError as error:
                messagebox.showerror("Жеребьёвка", str(error), parent=dialog)
                return
            self._mark()
            self._refresh()
            self.players_tree.selection_set(str(index))
            dialog.destroy()

        buttons = ttk.Frame(form)
        buttons.grid(row=5, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Сохранить", command=save).pack(side="right")
        ttk.Button(buttons, text="Отмена", command=dialog.destroy).pack(side="right", padx=6)
        dialog.bind("<Return>", lambda _event: save())

    def _edit_roster(self) -> None:
        if not self._is_team():
            return
        index = self._selected_player()
        if index is None:
            return
        team = self.tournament.teams[index]
        dialog = tk.Toplevel(self)
        dialog.title(f"Состав — {team.name}")
        dialog.geometry("560x460")
        dialog.transient(self)
        ttk.Label(dialog, text=f"Доска 1 сверху. В матче цвета чередуются. Досок в туре: {self.tournament.boards}. У игрока можно указать возраст и пол.").pack(anchor="w", padx=12, pady=(12, 6))
        box = tk.Listbox(dialog, font=("Segoe UI", 11), height=10)
        box.pack(fill="both", expand=True, padx=12)

        def member_line(number: int, member: Member) -> str:
            bits = [f"{number}. {member.name}"]
            if member.rating:
                bits.append(str(member.rating))
            if sex_label(member.sex):
                bits.append(sex_label(member.sex))
            if member.age is not None:
                bits.append(f"{member.age} лет")
            return "   ".join(bits)

        def refill(selected: int | None = None) -> None:
            box.delete(0, "end")
            for number, member in enumerate(team.members, start=1):
                box.insert("end", member_line(number, member))
            if selected is not None and 0 <= selected < len(team.members):
                box.selection_set(selected)
                box.activate(selected)

        refill()
        form = ttk.Frame(dialog)
        form.pack(fill="x", padx=12, pady=8)
        member_name = tk.StringVar()
        member_rating = tk.StringVar()
        member_age = tk.StringVar()
        member_sex = tk.StringVar()
        ttk.Entry(form, textvariable=member_name).pack(side="left", fill="x", expand=True)
        ttk.Entry(form, textvariable=member_rating, width=7).pack(side="left", padx=6)
        ttk.Entry(form, textvariable=member_age, width=4).pack(side="left")
        ttk.Combobox(form, textvariable=member_sex, values=("", "м", "ж"), width=3, state="readonly").pack(side="left", padx=6)

        def read_member() -> Member:
            name = " ".join(member_name.get().split())
            if not name:
                raise ValueError("Введите имя.")
            rating_text = member_rating.get().strip()
            try:
                rating = int(rating_text) if rating_text else 0
            except ValueError:
                raise ValueError("Рейтинг должен быть числом.") from None
            if rating < 0:
                raise ValueError("Рейтинг не может быть отрицательным.")
            return Member(name, rating, clean_age(member_age.get()), clean_sex(member_sex.get()))

        def add_member() -> None:
            try:
                team.members.append(read_member())
            except ValueError as error:
                messagebox.showerror("Жеребьёвка", str(error), parent=dialog)
                return
            member_name.set("")
            member_rating.set("")
            member_age.set("")
            member_sex.set("")
            refill(len(team.members) - 1)

        def selected_member() -> int | None:
            picked = box.curselection()
            return picked[0] if picked else None

        def delete_member() -> None:
            picked = selected_member()
            if picked is None:
                return
            del team.members[picked]
            member_name.set("")
            member_rating.set("")
            member_age.set("")
            member_sex.set("")
            refill()

        def load_member(_event=None) -> None:
            picked = selected_member()
            if picked is None:
                return
            member = team.members[picked]
            member_name.set(member.name)
            member_rating.set(str(member.rating or ""))
            member_age.set("" if member.age is None else str(member.age))
            member_sex.set(sex_label(member.sex))

        def write_member() -> None:
            picked = selected_member()
            if picked is None:
                add_member()
                return
            try:
                team.members[picked] = read_member()
            except ValueError as error:
                messagebox.showerror("Жеребьёвка", str(error), parent=dialog)
                return
            refill(picked)

        box.bind("<<ListboxSelect>>", load_member)

        def move(step: int) -> None:
            picked = selected_member()
            if picked is None:
                return
            target = picked + step
            if target < 0 or target >= len(team.members):
                return
            team.members[picked], team.members[target] = team.members[target], team.members[picked]
            refill(target)

        ttk.Button(form, text="На доску", command=add_member).pack(side="left")
        ttk.Button(form, text="Записать", command=write_member).pack(side="left", padx=6)
        actions = ttk.Frame(dialog)
        actions.pack(fill="x", padx=12, pady=(0, 12))
        ttk.Button(actions, text="Выше", command=lambda: move(-1)).pack(side="left")
        ttk.Button(actions, text="Ниже", command=lambda: move(1)).pack(side="left", padx=6)
        ttk.Button(actions, text="Убрать", command=delete_member).pack(side="left")

        def close() -> None:
            self._mark()
            self._refresh()
            self.players_tree.selection_set(str(index))
            dialog.destroy()

        ttk.Button(actions, text="Готово", command=close).pack(side="right")
        dialog.protocol("WM_DELETE_WINDOW", close)

    def _sync_status_box(self) -> None:
        index = self._selected_player()
        if index is None:
            return
        units = self.tournament.teams if self._is_team() else self.tournament.players
        player = units[index]
        for label, bye, withdrawn in self._statuses():
            if player.withdrawn == withdrawn and (withdrawn or player.next_bye == bye):
                self.status_var.set(label)
                return

    def _apply_status(self) -> None:
        index = self._selected_player()
        if index is None:
            return
        label = self.status_var.get()
        units = self.tournament.teams if self._is_team() else self.tournament.players
        for name, bye, withdrawn in self._statuses():
            if name == label:
                player = units[index]
                player.withdrawn = withdrawn
                player.next_bye = bye
                break
        self._mark()
        self._refresh()
        self.players_tree.selection_set(str(index))

    def _pair(self) -> None:
        self._read_meta()
        try:
            self.tournament.pair_next_round()
        except (ValueError, pairing.PairingError) as error:
            self._refresh()
            messagebox.showerror("Жеребьёвка", str(error))
            return
        self.round_index = len(self.tournament.rounds_played) - 1
        self._mark()
        self._refresh()

    def _delete_round(self) -> None:
        if not self.tournament.rounds_played:
            return
        if not messagebox.askyesno("Жеребьёвка", "Удалить последний тур вместе с его результатами?"):
            return
        try:
            self.tournament.delete_last_round()
        except ValueError as error:
            messagebox.showerror("Жеребьёвка", str(error))
            return
        self.round_index = max(0, len(self.tournament.rounds_played) - 1)
        self._mark()
        self._refresh()

    def _shift_round(self, step: int) -> None:
        if not self.tournament.rounds_played:
            return
        self.round_index = min(len(self.tournament.rounds_played) - 1, max(0, self.round_index + step))
        self._refresh_round()

    def _selected_game(self) -> tuple[str, ... ] | None:
        selected = self.games_tree.selection()
        if not selected:
            return None
        return tuple(selected[0].split(":"))

    def _set_result(self, result: str) -> None:
        selected = self._selected_game()
        if selected is None or not self.tournament.rounds_played:
            return
        round_index = int(selected[0])
        if round_index != len(self.tournament.rounds_played) - 1:
            messagebox.showinfo("Жеребьёвка", "Результаты прошлого тура закрыты. Удалите последние туры, если их нужно переиграть.")
            return
        if self._is_team():
            if len(selected) != 3 or selected[2] == "bye":
                return
            match = self.tournament.rounds_played[round_index][int(selected[1])]
            if match.is_bye:
                return
            board = match.boards[int(selected[2])]
            if not board.white_name or not board.black_name:
                return
            board.result = result
        else:
            game = self.tournament.rounds_played[round_index][int(selected[1])]
            if game.is_bye:
                return
            game.result = result
        self._mark()
        self._refresh()
        self.games_tree.selection_set(":".join(selected))

    def _cycle_result(self) -> None:
        selected = self._selected_game()
        if selected is None:
            return
        if self._is_team():
            if len(selected) != 3 or selected[2] == "bye":
                return
            match = self.tournament.rounds_played[int(selected[0])][int(selected[1])]
            if match.is_bye:
                return
            current = match.boards[int(selected[2])].result
        else:
            game = self.tournament.rounds_played[int(selected[0])][int(selected[1])]
            if game.is_bye:
                return
            current = game.result
        try:
            index = RESULT_ORDER.index(current or "")
        except ValueError:
            index = -1
        self._set_result(RESULT_ORDER[(index + 1) % len(RESULT_ORDER)])

    def _result_key(self, event: tk.Event) -> None:
        mapping = {"1": "1-0", "equal": "1/2", "0": "0-1", "plus": "+-", "minus": "-+", "x": "--"}
        code = mapping.get(event.keysym) or mapping.get(event.char)
        if code:
            self._set_result(code)

    def _excel_players(self) -> None:
        self._excel("игроки", reports.write_players, "Карточки игроков")

    def _excel_teams(self) -> None:
        if not self._is_team():
            messagebox.showinfo("Жеребьёвка", "Карточки команд делаются в командном турнире.")
            return
        self._excel("команды", reports.write_teams, "Карточки команд")

    def _excel_pairing(self) -> None:
        if not self.tournament.rounds_played:
            messagebox.showinfo("Жеребьёвка", "Сначала сделайте жеребьёвку тура.")
            return
        indexes = None
        if len(self.tournament.rounds_played) > 1:
            current = messagebox.askyesnocancel(
                "Жеребьёвка",
                f"Да — все {len(self.tournament.rounds_played)} тура.\nНет — только тур {self.round_index + 1}, который сейчас на экране.",
            )
            if current is None:
                return
            if not current:
                indexes = [self.round_index]
        self._excel("жеребьёвка", lambda tournament, path: reports.write_pairing(tournament, path, indexes), "Жеребьёвка")

    def _excel_boards(self) -> None:
        self._excel("доски", reports.write_boards, "Результаты по доскам")

    def _excel(self, suffix: str, writer, title: str) -> None:
        self._read_meta()
        path = filedialog.asksaveasfilename(
            title=title,
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            initialfile=self._excel_filename(suffix),
            initialdir=str(self.path.parent) if self.path else None,
        )
        if not path:
            return
        try:
            writer(self.tournament, Path(path))
        except (OSError, ValueError) as error:
            messagebox.showerror("Жеребьёвка", str(error))
            return
        self._open_workbook(Path(path))

    def _excel_filename(self, suffix: str) -> str:
        cleaned = "".join(ch for ch in self.tournament.name if ch not in '<>:"/\\|?*').strip() or "турнир"
        return f"{cleaned} — {suffix}.xlsx"

    def _open_workbook(self, path: Path) -> None:
        try:
            os.startfile(path)  # type: ignore[attr-defined]
        except OSError as error:
            messagebox.showinfo("Жеребьёвка", f"Файл сохранён:\n{path}\n\n{error}")
            return
        self.status.configure(text=f"Открыт файл Excel: {path.name}. Печать: Файл → Печать, страница уже альбомная.")

    def _export(self) -> None:
        if not self.tournament.rounds_played:
            messagebox.showinfo("Жеребьёвка", "Сначала сделайте жеребьёвку тура.")
            return
        path = filedialog.asksaveasfilename(
            title="Экспорт тура",
            defaultextension=".txt",
            filetypes=[("Текст", "*.txt")],
            initialfile=f"тур-{self.round_index + 1}.txt",
        )
        if not path:
            return
        Path(path).write_text(self._round_export(), encoding="utf-8")

    def _round_export(self) -> str:
        if self._is_team():
            return self.tournament.export_round(self.round_index)
        return round_text(self.tournament, self.round_index)

    def _confirm_discard(self) -> bool:
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel("Жеребьёвка", "Сохранить турнир?")
        if answer is None:
            return False
        if answer:
            return self._save()
        return True

    def _new(self) -> None:
        if not self._confirm_discard():
            return
        self.tournament = self._blank()
        self.path = None
        self.round_index = 0
        self._unmark()
        self._refresh()

    def _open(self) -> None:
        if not self._confirm_discard():
            return
        path = filedialog.askopenfilename(title="Открыть турнир", filetypes=[("Турнир", "*.json")])
        if not path:
            return
        try:
            self.tournament = load_tournament(Path(path))
        except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
            messagebox.showerror("Жеребьёвка", f"Не удалось открыть файл.\n{error}")
            return
        self.path = Path(path)
        self.round_index = max(0, len(self.tournament.rounds_played) - 1)
        self._unmark()
        self._refresh()

    def _save(self) -> bool:
        self._read_meta()
        path = self.path
        if path is None:
            selected = filedialog.asksaveasfilename(
                title="Сохранить турнир",
                defaultextension=".json",
                filetypes=[("Турнир", "*.json")],
                initialfile="турнир.json",
            )
            if not selected:
                return False
            path = Path(selected)
        try:
            self.tournament.save(path)
        except OSError as error:
            messagebox.showerror("Жеребьёвка", str(error))
            return False
        self.path = path
        self._unmark()
        self._refresh_status()
        return True

    def _close(self) -> None:
        if self._confirm_discard():
            self.destroy()

    def _refresh(self) -> None:
        self._loading = True
        self.name_var.set(self.tournament.name)
        self.rounds_var.set(self.tournament.rounds)
        self.color_var.set("Чёрные" if self.tournament.initial_color == "black" else "Белые")
        self.baku_var.set(self.tournament.baku)
        self.kind_var.set("Командный" if self._is_team() else "Личный")
        self.avoid_var.set(getattr(self.tournament, "avoid_same_club", True))
        if self._is_team():
            self.boards_var.set(self.tournament.boards)
        locked = self.tournament.started
        self.color_box.configure(state="disabled" if locked else "readonly")
        self.kind_box.configure(state="disabled" if locked else "readonly")
        self.baku_check.configure(state="disabled" if locked else "normal")
        self.boards_spin.configure(state="disabled" if locked or not self._is_team() else "normal")
        self.avoid_check.configure(state="normal" if not self._is_team() else "disabled")
        for widget in (self.rating_entry, self.age_entry, self.sex_box, self.club_entry):
            widget.pack_forget()
        if self._is_team():
            self.roster_button.pack(side="right", padx=6)
        else:
            for widget in (self.rating_entry, self.age_entry, self.sex_box, self.club_entry):
                widget.pack(side="left", padx=(0, 6), before=self.add_button)
            self.roster_button.pack_forget()
        self.players_frame.configure(text="Команды" if self._is_team() else "Игроки")
        self.players_hint.configure(
            text="Двойной щелчок открывает состав: доска, рейтинг, возраст и пол. Номера — по сумме рейтингов."
            if self._is_team()
            else "Строка: имя, рейтинг, возраст, пол, клуб. Двойной щелчок правит эти данные. Номера — по рейтингу до первого тура."
        )
        self.status_box.configure(values=[item[0] for item in self._statuses()])
        self._loading = False
        self._refresh_players()
        self._refresh_round()
        self._refresh_table()
        self._refresh_status()

    def _refresh_players(self) -> None:
        selected = self.players_tree.selection()
        team_mode = self._is_team()
        self.players_tree.heading("name", text="Команда" if team_mode else "Игрок")
        self.players_tree.heading("club", text="Состав" if team_mode else "Клуб")
        self.players_tree.heading("rating", text="Σ рейт." if team_mode else "Рейт.")
        self.players_tree.heading("points", text="Матч" if team_mode else "Очки")
        self.players_tree.heading("sex", text="" if team_mode else "Пол")
        self.players_tree.heading("age", text="" if team_mode else "Возраст")
        self.players_tree.column("sex", width=0 if team_mode else 40, minwidth=0 if team_mode else 36, stretch=False)
        self.players_tree.column("age", width=0 if team_mode else 64, minwidth=0 if team_mode else 52, stretch=False)
        self.players_tree.delete(*self.players_tree.get_children())
        units = self.tournament.teams if team_mode else self.tournament.players
        for index, unit in enumerate(units):
            number = index + 1
            if team_mode:
                points = str(self.tournament.match_points(number))
                club = f"{len(unit.members)}/{self.tournament.boards}"
            else:
                points = f"{self.tournament.points(number):.1f}"
                club = unit.club
            sex = "" if team_mode else sex_label(unit.sex)
            age = "" if team_mode or unit.age is None else unit.age
            self.players_tree.insert(
                "",
                "end",
                iid=str(index),
                values=(number, unit.name, sex, age, club, unit.rating, points, _status_label(unit, team_mode)),
            )
        if selected and self.players_tree.exists(selected[0]):
            self.players_tree.selection_set(selected[0])

    def _refresh_round(self) -> None:
        self.games_tree.delete(*self.games_tree.get_children())
        played = self.tournament.rounds_played
        if not played:
            self.round_label.configure(text="Тур не создан")
            return
        self.round_index = min(self.round_index, len(played) - 1)
        self.round_label.configure(text=f"Тур {self.round_index + 1} из {self.tournament.rounds}")
        if self._is_team():
            for match_index, match in enumerate(played[self.round_index]):
                if match.is_bye:
                    self.games_tree.insert(
                        "",
                        "end",
                        iid=f"{self.round_index}:{match_index}:bye",
                        values=("бай", self.tournament.team(match.white).name, "—", BYE_LABELS.get(match.bye or "", "бай")),
                    )
                    continue
                for board_index, board in enumerate(match.boards):
                    result = RESULT_LABELS.get(board.result or "", "…")
                    self.games_tree.insert(
                        "",
                        "end",
                        iid=f"{self.round_index}:{match_index}:{board_index}",
                        values=(
                            f"{match_index + 1}.{board_index + 1}",
                            board.white_name or "без игрока",
                            board.black_name or "без игрока",
                            result,
                        ),
                    )
            return
        board = 1
        for game_index, game in enumerate(played[self.round_index]):
            if game.is_bye:
                white = self.tournament.player(game.white).name
                black = "—"
                result = BYE_LABELS.get(game.result or "", "бай")
                board_text = "—"
            else:
                white = self.tournament.player(game.white).name
                black = self.tournament.player(game.black).name
                result = RESULT_LABELS.get(game.result or "", "…")
                board_text = str(board)
                board += 1
            self.games_tree.insert("", "end", iid=f"{self.round_index}:{game_index}", values=(board_text, white, black, result))

    def _refresh_table(self) -> None:
        spec = TEAM_TABLE if self._is_team() else INDIVIDUAL_TABLE
        self.table.configure(columns=[item[0] for item in spec])
        for key, title, width, anchor in spec:
            self.table.heading(key, text=title)
            self.table.column(key, width=width, anchor=anchor, stretch=key == "name")
        self.table.delete(*self.table.get_children())
        for row in self.tournament.standings():
            name = row["name"] + (" (снят)" if row["withdrawn"] else "")
            if self._is_team():
                values = (
                    row["place"],
                    row["number"],
                    name,
                    row["points"],
                    f"{row['game_points']:.1f}",
                    f"{row['buchholz']:.1f}",
                    f"{row['sonneborn']:.2f}",
                )
            else:
                values = (
                    row["place"],
                    row["number"],
                    name,
                    f"{row['points']:.1f}",
                    f"{row['buchholz']:.1f}",
                    f"{row['buchholz_cut']:.1f}",
                    f"{row['sonneborn']:.2f}",
                    row["wins"],
                )
            self.table.insert("", "end", values=values)
        self.table_hint.configure(
            text="Матчевые очки 2/1/0, затем игровые. Бай на 2 очка даёт половину досок игровыми. Бухгольц и Зоннеборн считаются по матчевым."
            if self._is_team()
            else "Очки, Бухгольц, Бухгольц без худшего результата, Зоннеборн-Бергер, число побед. Несыгранная партия в Бухгольце идёт как свой результат."
        )

    def _refresh_status(self) -> None:
        engine = pairing.engine_version()
        played = len(self.tournament.rounds_played)
        count = len(self.tournament.teams if self._is_team() else self.tournament.players)
        label = "Команд" if self._is_team() else "Игроков"
        waiting = ""
        if played and not self.tournament.round_complete(-1):
            waiting = " Внесите результаты, затем жеребите следующий тур."
        self.status.configure(text=f"{engine}. {label}: {count}. Туров сыграно: {played}.{waiting}")


def _status_label(player, team: bool = False) -> str:
    if player.withdrawn:
        return "снята" if team else "снят"
    if team:
        return {"": "играет", "U": "бай 2", "F": "бай 2", "H": "бай 1", "Z": "ноль"}.get(player.next_bye, "играет")
    return {"": "играет", "H": "бай ½", "Z": "бай 0", "F": "бай 1"}.get(player.next_bye, "играет")


def _parse_player(raw: str) -> tuple[str, int, str, int | None, str] | None:
    line = raw.strip()
    if not line or line.startswith("#"):
        return None
    if ";" in line:
        parts = [part.strip() for part in line.split(";")]
        if not parts[0]:
            raise ValueError("Введите имя.")
        rating = int(parts[1] or 0) if len(parts) > 1 and parts[1] else 0
        club = parts[2] if len(parts) > 2 else ""
        age, sex = _age_and_sex(parts[3:])
        return parts[0], rating, club, age, sex
    tokens = line.split()
    sex = ""
    age = None
    if tokens and _is_sex(tokens[-1]):
        sex = clean_sex(tokens.pop())
    if len(tokens) >= 2 and tokens[-1].isdigit() and tokens[-2].isdigit():
        age = clean_age(tokens.pop())
    if tokens and tokens[-1].isdigit():
        rating = int(tokens.pop())
        name = " ".join(tokens)
        return name, rating, "", age, sex
    return line, 0, "", age, sex


def _parse_member(raw: str) -> tuple[str, int, int | None, str] | None:
    line = raw.strip()
    if not line or line.startswith("#"):
        return None
    if ";" in line:
        parts = [part.strip() for part in line.split(";")]
        if not parts[0]:
            raise ValueError("Введите имя.")
        rating = int(parts[1] or 0) if len(parts) > 1 and parts[1] else 0
        age, sex = _age_and_sex(parts[2:])
        return parts[0], rating, age, sex
    name, rating, _club, age, sex = _parse_player(line) or ("", 0, "", None, "")
    return name, rating, age, sex


def _age_and_sex(parts: list[str]) -> tuple[int | None, str]:
    age = None
    sex = ""
    for part in parts:
        if not part:
            continue
        if _is_sex(part):
            if sex:
                raise ValueError(f"Пол указан дважды: «{part}».")
            sex = clean_sex(part)
            continue
        if part.isdigit():
            if age is not None:
                raise ValueError(f"Лишнее число «{part}».")
            age = clean_age(part)
            continue
        raise ValueError(f"Не понял «{part}»: возраст — число, пол — м или ж.")
    return age, sex


def _is_sex(value: str) -> bool:
    try:
        return bool(clean_sex(value))
    except ValueError:
        return False


def _paste_teams(tournament: TeamTournament, text: str) -> None:
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            tournament.add_team(line[1:])
            current = tournament.teams[-1]
            continue
        if current is None:
            raise ValueError("Сначала строка команды, она начинается с #.")
        parsed = _parse_member(line)
        if parsed is None or not parsed[0]:
            continue
        current.members.append(Member(parsed[0], parsed[1], parsed[2], parsed[3]))


def _safe_int(variable: tk.Variable) -> int:
    try:
        return int(variable.get())
    except (tk.TclError, ValueError):
        return 0


def load_tournament(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("kind") == "team":
        return TeamTournament.from_dict(data)
    return Tournament.from_dict(data)


if __name__ == "__main__":
    App().mainloop()
