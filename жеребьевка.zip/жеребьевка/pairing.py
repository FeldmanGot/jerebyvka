"""Запись TRF и вызов bbpPairings (голландская система FIDE)."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

ENGINE = Path(__file__).resolve().parent / "engine" / "bbpPairings.exe"
CREATE_NO_WINDOW = 0x08000000


class PairingError(Exception):
    pass


def engine_version() -> str:
    if not ENGINE.is_file():
        return "движок не найден"
    result = subprocess.run(
        [str(ENGINE)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=CREATE_NO_WINDOW,
    )
    line = (result.stdout or result.stderr or "").strip().splitlines()
    return line[0] if line else "bbpPairings"


def _work_dir() -> Path:
    for candidate in (Path(r"C:\Temp\zhereb"), Path(os.environ.get("TEMP", r"C:\Temp")) / "zhereb"):
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / "probe.txt"
            probe.write_text("ok", encoding="ascii")
            probe.unlink()
            # bbpPairings не открывает файлы, если в пути есть нелатинские буквы.
            str(candidate).encode("ascii")
            return candidate
        except (OSError, UnicodeEncodeError):
            continue
    raise PairingError("Не удалось создать папку для файла жеребьёвки.")


def _block(opponent: int, color: str, result: str) -> str:
    opponent_text = "0000" if opponent == 0 else f"{opponent:4d}"
    text = f"{opponent_text} {color} {result}  "
    if len(text) != 10:
        raise PairingError(f"Неверная длина поля тура: {text!r}")
    return text


def player_line(pairing_number: int, name: str, rating: int, points: float, games: list[tuple[int, str, str]]) -> str:
    chars = [" "] * (91 + 10 * len(games))
    chars[0:3] = list("001")
    chars[4:8] = list(f"{pairing_number:4d}")
    chars[9] = "m"
    chars[14:47] = list(name[:33].ljust(33))
    chars[48:52] = list(f"{max(0, min(int(rating), 9999)):4d}")
    points_text = f"{points:4.1f}"
    if len(points_text) != 4:
        raise PairingError("Слишком большой счёт для формата TRF.")
    chars[80:84] = list(points_text)
    for index, (opponent, color, result) in enumerate(games):
        start = 91 + 10 * index
        chars[start : start + 10] = list(_block(opponent, color, result))
    return "".join(chars)


def bye_line(round_number: int, pairing_numbers: list[int]) -> str:
    width = 10 + 5 * len(pairing_numbers)
    chars = [" "] * width
    chars[0:3] = list("240")
    chars[6:9] = list(f"{round_number:3d}")
    for index, pairing_number in enumerate(pairing_numbers):
        start = 10 + 5 * index
        chars[start : start + 4] = list(f"{pairing_number:4d}")
    return "".join(chars)


def write_trf(path: Path, header: list[str], player_rows: list[str], excluded: list[int], round_number: int) -> None:
    lines = list(header) + list(player_rows)
    if excluded:
        lines.append(bye_line(round_number, excluded))
    path.write_bytes(("\r\n".join(lines) + "\r\n").encode("utf-8"))


def parse_pairs(text: str) -> list[tuple[int, int]]:
    pairs: list[tuple[int, int]] = []
    for raw in text.splitlines():
        parts = raw.split()
        if len(parts) < 2:
            continue
        pairs.append((int(parts[0]), int(parts[1])))
    return pairs


def pair(header: list[str], player_rows: list[str], excluded: list[int], round_number: int) -> list[tuple[int, int]]:
    if not ENGINE.is_file():
        raise PairingError(f"Не найден {ENGINE}")
    folder = _work_dir()
    trf_path = folder / "tournament.trf"
    out_path = folder / "pairings.txt"
    write_trf(trf_path, header, player_rows, excluded, round_number)
    if out_path.exists():
        out_path.unlink()
    result = subprocess.run(
        [str(ENGINE), "--dutch", str(trf_path), "-p", str(out_path)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=CREATE_NO_WINDOW,
    )
    stderr = (result.stderr or "").strip()
    if result.returncode != 0 or not out_path.exists():
        detail = stderr or f"код {result.returncode}"
        if result.returncode == 1:
            detail = "Движок не нашёл допустимую жеребьёвку. " + detail
        raise PairingError(detail)
    return parse_pairs(out_path.read_text(encoding="utf-8", errors="replace"))
