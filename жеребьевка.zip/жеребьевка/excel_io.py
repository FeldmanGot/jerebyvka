"""Книга Excel без сторонних библиотек: листы, рамки, альбомная печать A4."""

from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.sax.saxutils import escape


@dataclass
class Cell:
    value: object = None
    style: str = "text"
    link: str | None = None


@dataclass
class Sheet:
    name: str
    widths: list[float]
    landscape: bool = True
    rows: list[list[Cell]] = field(default_factory=list)
    merges: list[tuple[int, int, int, int]] = field(default_factory=list)
    heights: dict[int, float] = field(default_factory=dict)

    def add(self, values: list[object], height: float = 20) -> int:
        row: list[Cell] = []
        for item in values:
            row.append(item if isinstance(item, Cell) else Cell(item))
        width = len(self.widths)
        if len(row) < width:
            row.extend(Cell(None, "gap") for _ in range(width - len(row)))
        self.rows.append(row[:width])
        index = len(self.rows) - 1
        self.heights[index] = height
        return index

    def merge(self, row: int, start_col: int, end_col: int) -> None:
        self.merges.append((row, start_col, row, end_col))


class Workbook:
    def __init__(self) -> None:
        self.sheets: list[Sheet] = []
        self._used: set[str] = set()

    def add(self, title: str, widths: list[float], landscape: bool = True) -> Sheet:
        sheet = Sheet(self._name(title), widths, landscape)
        self.sheets.append(sheet)
        return sheet

    def save(self, path: Path) -> None:
        if not self.sheets:
            raise ValueError("В книге нет листов.")
        path = Path(path)
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", _content_types(len(self.sheets)))
            archive.writestr("_rels/.rels", _root_rels())
            archive.writestr("xl/workbook.xml", _workbook(self.sheets))
            archive.writestr("xl/_rels/workbook.xml.rels", _workbook_rels(len(self.sheets)))
            archive.writestr("xl/styles.xml", _styles())
            for index, sheet in enumerate(self.sheets, start=1):
                archive.writestr(f"xl/worksheets/sheet{index}.xml", _worksheet(sheet))

    def _name(self, title: str) -> str:
        cleaned = "".join(ch for ch in str(title) if ch not in "[]:*?/\\").strip() or "Лист"
        cleaned = cleaned[:31]
        candidate = cleaned
        number = 2
        while candidate.casefold() in self._used:
            suffix = f" {number}"
            candidate = cleaned[: 31 - len(suffix)] + suffix
            number += 1
        self._used.add(candidate.casefold())
        return candidate


_STYLES = {
    "text": 1,
    "center": 2,
    "title": 3,
    "subtitle": 4,
    "header": 5,
    "section": 6,
    "points": 7,
    "link": 8,
    "gap": 0,
    "zebra": 9,
}


def _worksheet(sheet: Sheet) -> str:
    width = max(len(sheet.widths), 1)
    last_row = max(len(sheet.rows), 1)
    last_ref = f"{_column(width)}{last_row}"
    cols = "".join(
        f'<col min="{index}" max="{index}" width="{size}" customWidth="1"/>'
        for index, size in enumerate(sheet.widths, start=1)
    )
    rows: list[str] = []
    links: list[str] = []
    for row_index, row in enumerate(sheet.rows):
        cells: list[str] = []
        for col_index, cell in enumerate(row, start=1):
            ref = f"{_column(col_index)}{row_index + 1}"
            style = _STYLES.get(cell.style, 1)
            cells.append(_cell_xml(ref, cell.value, style))
            if cell.link:
                location = _sheet_location(cell.link)
                links.append(f'<hyperlink ref="{ref}" location="{escape(location)}" display="{escape(cell.link)}"/>')
        height = sheet.heights.get(row_index, 20)
        rows.append(f'<row r="{row_index + 1}" ht="{height}" customHeight="1" spans="1:{width}">{"".join(cells)}</row>')
    merges = ""
    if sheet.merges:
        items = []
        for r1, c1, r2, c2 in sheet.merges:
            items.append(f'<mergeCell ref="{_column(c1 + 1)}{r1 + 1}:{_column(c2 + 1)}{r2 + 1}"/>')
        merges = f'<mergeCells count="{len(items)}">{"".join(items)}</mergeCells>'
    hyperlinks = f'<hyperlinks>{"".join(links)}</hyperlinks>' if links else ""
    orientation = "landscape" if sheet.landscape else "portrait"
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
<dimension ref="A1:{last_ref}"/>
<sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews>
<sheetFormatPr defaultRowHeight="18"/>
<cols>{cols}</cols>
<sheetData>{"".join(rows)}</sheetData>
{merges}
{hyperlinks}
<printOptions horizontalCentered="1"/>
<pageMargins left="0.45" right="0.45" top="0.5" bottom="0.5" header="0.2" footer="0.25"/>
<pageSetup paperSize="9" orientation="{orientation}" fitToWidth="1" fitToHeight="0"/>
<headerFooter>
<oddFooter>&amp;L{escape(sheet.name)}&amp;CСтр. &amp;P из &amp;N</oddFooter>
</headerFooter>
</worksheet>
"""


def _cell_xml(ref: str, value: object, style: int) -> str:
    if value is None or value == "":
        return f'<c r="{ref}" s="{style}"/>'
    if isinstance(value, bool):
        value = int(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return f'<c r="{ref}" s="{style}"><v>{value}</v></c>'
    if isinstance(value, float):
        text = f"{value:.2f}".rstrip("0").rstrip(".")
        return f'<c r="{ref}" s="{style}"><v>{text}</v></c>'
    text = "".join(ch for ch in str(value) if ch in "\t\n\r" or ord(ch) >= 32)
    return f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{escape(text)}</t></is></c>'


def _column(number: int) -> str:
    letters = ""
    while number:
        number, rest = divmod(number - 1, 26)
        letters = chr(65 + rest) + letters
    return letters


def _sheet_location(name: str) -> str:
    return f"'{name.replace(chr(39), chr(39) * 2)}'!A1"


def _content_types(sheet_count: int) -> str:
    overrides = [
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
    ]
    for index in range(1, sheet_count + 1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    body = "".join(overrides)
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
{body}
</Types>
"""


def _root_rels() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>
"""


def _workbook(sheets: list[Sheet]) -> str:
    items = []
    for index, sheet in enumerate(sheets, start=1):
        items.append(f'<sheet name="{escape(sheet.name)}" sheetId="{index}" r:id="rId{index}"/>')
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>{"".join(items)}</sheets>
</workbook>
"""


def _workbook_rels(sheet_count: int) -> str:
    items = []
    for index in range(1, sheet_count + 1):
        items.append(
            f'<Relationship Id="rId{index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{index}.xml"/>'
        )
    style_id = sheet_count + 1
    items.append(
        f'<Relationship Id="rId{style_id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
    )
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
{"".join(items)}
</Relationships>
"""


def _styles() -> str:
    def xf(font: int, fill: int, border: int, horizontal: str, wrap: int = 0) -> str:
        return (
            f'<xf numFmtId="0" fontId="{font}" fillId="{fill}" borderId="{border}" xfId="0" '
            f'applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
            f'<alignment horizontal="{horizontal}" vertical="center" wrapText="{wrap}"/></xf>'
        )

    fonts = """
<font><sz val="11"/><name val="Calibri"/><color rgb="FF1C2421"/></font>
<font><b/><sz val="18"/><name val="Calibri"/><color rgb="FF1E3D34"/></font>
<font><b/><sz val="12"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font>
<font><b/><sz val="12"/><name val="Calibri"/><color rgb="FF1E3D34"/></font>
<font><b/><sz val="11"/><name val="Calibri"/><color rgb="FF1C2421"/></font>
<font><u/><sz val="11"/><name val="Calibri"/><color rgb="FF1D4E89"/></font>
""".strip()
    fills = """
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF1E3D34"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE7F0EC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF7FAF8"/><bgColor indexed="64"/></patternFill></fill>
""".strip()
    thin = '<left style="thin"><color rgb="FFB7C4BE"/></left><right style="thin"><color rgb="FFB7C4BE"/></right><top style="thin"><color rgb="FFB7C4BE"/></top><bottom style="thin"><color rgb="FFB7C4BE"/></bottom><diagonal/>'
    empty_border = "<left/><right/><top/><bottom/><diagonal/>"
    xfs = [
        xf(0, 0, 0, "left"),
        xf(0, 0, 1, "left", 1),
        xf(0, 0, 1, "center", 1),
        xf(1, 0, 0, "left"),
        xf(3, 0, 0, "left", 1),
        xf(2, 2, 1, "center", 1),
        xf(4, 3, 1, "left", 1),
        xf(4, 0, 1, "center", 1),
        xf(5, 0, 1, "left"),
        xf(0, 4, 1, "left", 1),
    ]
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="6">{fonts}</fonts>
<fills count="5">{fills}</fills>
<borders count="2"><border>{empty_border}</border><border>{thin}</border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="{len(xfs)}">{"".join(xfs)}</cellXfs>
</styleSheet>
"""
