"""Турнир: игроки, результаты, таблица и вызов голландской жеребьёвки."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import pairing

# Результат партии с точки зрения белых.
PLAYED = {
    "1-0": ("1", "0", 2, 0),
    "1/2": ("=", "=", 1, 1),
    "0-1": ("0", "1", 0, 2),
    "+-": ("+", "-", 2, 0),
    "-+": ("-", "+", 0, 2),
    "--": ("-", "-", 0, 0),
}
BYE_POINTS = {"U": 2, "F": 2, "H": 1, "Z": 0}
BYE_LABELS = {"U": "бай", "F": "бай 1", "H": "бай ½", "Z": "не играл"}


def clean_sex(value, *, strict: bool = True) -> str:
    text = str(value or "").strip().casefold().replace("ё", "е").replace(".", "")
    if text in {"", "-", "—"}:
        return ""
    if text in {"м", "m", "муж", "мужской", "male"}:
        return "m"
    if text in {"ж", "f", "жен", "женский", "female"}:
        return "f"
    if strict:
        raise ValueError("Пол укажите буквами м или ж.")
    return ""


def sex_label(value: str) -> str:
    return {"m": "м", "f": "ж"}.get(value or "", "")


def clean_age(value, *, strict: bool = True) -> int | None:
    if value is None:
        return None
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return None
    if isinstance(value, float) and not value.is_integer():
        if strict:
            raise ValueError("Возраст должен быть целым числом от 0 до 120.")
        return None
    try:
        age = int(value)
    except (TypeError, ValueError):
        if strict:
            raise ValueError("Возраст должен быть числом от 0 до 120.") from None
        return None
    if not 0 <= age <= 120:
        if strict:
            raise ValueError("Возраст должен быть числом от 0 до 120.")
        return None
    return age
RESULT_LABELS = {
    "1-0": "1–0",
    "1/2": "½–½",
    "0-1": "0–1",
    "+-": "+/–",
    "-+": "–/+",
    "--": "0–0",
}


@dataclass
class Player:
    name: str
    rating: int = 0
    club: str = ""
    age: int | None = None
    sex: str = ""
    withdrawn: bool = False
    next_bye: str = ""  # H, Z, F — только на ближайший тур


@dataclass
class Game:
    white: int
    black: int | None
    result: str | None = None

    @property
    def is_bye(self) -> bool:
        return self.black is None


@dataclass
class Tournament:
    kind: str = "individual"
    name: str = "Турнир"
    rounds: int = 5
    initial_color: str = "white"
    baku: bool = False
    avoid_same_club: bool = True
    players: list[Player] = field(default_factory=list)
    rounds_played: list[list[Game]] = field(default_factory=list)

    def pairing_number(self, index: int) -> int:
        return index + 1

    def index_of(self, pairing_number: int) -> int:
        return pairing_number - 1

    def player(self, pairing_number: int) -> Player:
        return self.players[self.index_of(pairing_number)]

    @property
    def started(self) -> bool:
        return bool(self.rounds_played)

    def sort_by_rating(self) -> None:
        if self.started:
            raise ValueError("Номера уже присвоены: тур начат.")
        indexed = list(enumerate(self.players))
        indexed.sort(key=lambda item: (-item[1].rating, item[1].name.casefold(), item[0]))
        self.players = [player for _, player in indexed]

    def add_player(self, name: str, rating: int, club: str = "", age: int | None = None, sex: str = "") -> None:
        name = " ".join(name.split())
        if not name:
            raise ValueError("Введите имя.")
        player = Player(
            name=name,
            rating=max(0, int(rating)),
            club=" ".join(club.split()),
            age=clean_age(age),
            sex=clean_sex(sex),
        )
        self.players.append(player)
        number = len(self.players)
        for games in self.rounds_played:
            games.append(Game(white=number, black=None, result="Z"))

    def remove_player(self, index: int) -> None:
        if self.started:
            raise ValueError("После старта игрока можно только снять с жеребьёвки.")
        del self.players[index]

    def points_halves(self, pairing_number: int) -> int:
        total = 0
        for games in self.rounds_played:
            for game in games:
                total += _game_halves(game, pairing_number)
        return total

    def points(self, pairing_number: int) -> float:
        return self.points_halves(pairing_number) / 2

    def pair_next_round(self) -> list[Game]:
        if len(self.players) < 2:
            raise ValueError("Нужно хотя бы два игрока.")
        if len(self.rounds_played) >= self.rounds:
            raise ValueError("Все туры уже сыграны.")
        if self.rounds_played and not self.round_complete(-1):
            raise ValueError("Сначала внесите результаты текущего тура.")
        if not self.started:
            self.sort_by_rating()

        round_number = len(self.rounds_played) + 1
        excluded: list[int] = []
        rows: list[str] = []
        for index, player in enumerate(self.players):
            number = index + 1
            if player.withdrawn or player.next_bye:
                excluded.append(number)
            rows.append(
                pairing.player_line(
                    number,
                    player.name,
                    player.rating,
                    self.points(number),
                    self._history(number),
                )
            )

        header = [
            f"012 {self.name}",
            f"XXR {self.rounds}",
            "XXC " + ("white1" if self.initial_color == "white" else "black1"),
            "192 " + ("FIDE_DUTCH_2025_BAKU" if self.baku else "FIDE_DUTCH_2025"),
            *self._club_lines(),
        ]
        pairs = pairing.pair(header, rows, excluded, round_number)
        games = self._games_from_pairs(pairs, excluded)
        self.rounds_played.append(games)
        for player in self.players:
            if not player.withdrawn:
                player.next_bye = ""
        return games

    def delete_last_round(self) -> None:
        if not self.rounds_played:
            raise ValueError("Туров ещё нет.")
        self.rounds_played.pop()

    def round_complete(self, index: int) -> bool:
        return all(game.result for game in self.rounds_played[index])

    def _club_lines(self) -> list[str]:
        if not self.avoid_same_club:
            return []
        groups: dict[str, list[int]] = {}
        for number, player in enumerate(self.players, start=1):
            club = player.club.strip()
            if club:
                groups.setdefault(club.casefold(), []).append(number)
        return [f"XXP {' '.join(str(number) for number in numbers)}" for numbers in groups.values() if len(numbers) >= 2]

    def _history(self, pairing_number: int) -> list[tuple[int, str, str]]:
        history: list[tuple[int, str, str]] = []
        for games in self.rounds_played:
            game = next(item for item in games if item.white == pairing_number or item.black == pairing_number)
            if game.result is None:
                raise ValueError("В истории тура есть партия без результата.")
            history.append(_trf_fields(game, pairing_number))
        return history

    def _games_from_pairs(self, pairs: list[tuple[int, int]], excluded: list[int]) -> list[Game]:
        known = set(range(1, len(self.players) + 1))
        seen: set[int] = set()
        games: list[Game] = []
        for white, black in pairs:
            if white not in known or (black not in known and black != 0):
                raise pairing.PairingError(f"Движок вернул неизвестный номер: {white} {black}")
            if white in seen or (black and black in seen):
                raise pairing.PairingError("Движок повторил номер игрока.")
            seen.add(white)
            if black == 0:
                games.append(Game(white=white, black=None, result="U"))
            else:
                seen.add(black)
                games.append(Game(white=white, black=black, result=None))
        for number in excluded:
            if number in seen:
                raise pairing.PairingError(f"Игрок {number} получил и бай, и пару.")
            player = self.player(number)
            result = "Z" if player.withdrawn else (player.next_bye or "Z")
            games.append(Game(white=number, black=None, result=result))
            seen.add(number)
        missing = known - seen
        if missing:
            raise pairing.PairingError("Движок вернул неполную жеребьёвку: " + ", ".join(map(str, sorted(missing))))
        return games

    def standings(self) -> list[dict]:
        points = {number: self.points(number) for number in range(1, len(self.players) + 1)}
        rows = []
        for number, player in enumerate(self.players, start=1):
            contributions: list[float] = []
            sonneborn = 0.0
            wins = 0
            for games in self.rounds_played:
                game = next((item for item in games if item.white == number or item.black == number), None)
                if game is None or game.result is None:
                    continue
                halves = _game_halves(game, number)
                if not game.is_bye and halves == 2 and game.result in {"1-0", "0-1", "+-", "-+"}:
                    wins += 1
                if game.is_bye or game.result in {"+-", "-+", "--"}:
                    contributions.append(points[number])
                    continue
                opponent = game.black if game.white == number else game.white
                assert opponent is not None
                contributions.append(points[opponent])
                if halves == 2:
                    sonneborn += points[opponent]
                elif halves == 1:
                    sonneborn += points[opponent] / 2
            buchholz = sum(contributions)
            buchholz_cut = buchholz - min(contributions) if len(contributions) >= 2 else 0.0
            rows.append(
                {
                    "number": number,
                    "name": player.name,
                    "club": player.club,
                    "rating": player.rating,
                    "points": points[number],
                    "buchholz": buchholz,
                    "buchholz_cut": buchholz_cut,
                    "sonneborn": sonneborn,
                    "wins": wins,
                    "withdrawn": player.withdrawn,
                }
            )
        rows.sort(key=lambda row: (-row["points"], -row["buchholz"], -row["buchholz_cut"], -row["sonneborn"], -row["wins"], row["number"]))
        place = 0
        tie_keys = ("points", "buchholz", "buchholz_cut", "sonneborn", "wins")
        for index, row in enumerate(rows):
            previous = rows[index - 1] if index else None
            if previous and all(previous[key] == row[key] for key in tie_keys):
                row["place"] = previous["place"]
            else:
                place = index + 1
                row["place"] = place
        return rows

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "rounds": self.rounds,
            "initial_color": self.initial_color,
            "kind": "individual",
            "baku": self.baku,
            "avoid_same_club": self.avoid_same_club,
            "players": [
                {
                    "name": player.name,
                    "rating": player.rating,
                    "club": player.club,
                    "age": player.age,
                    "sex": player.sex,
                    "withdrawn": player.withdrawn,
                    "next_bye": player.next_bye,
                }
                for player in self.players
            ],
            "rounds_played": [
                [{"white": game.white, "black": game.black, "result": game.result} for game in games]
                for games in self.rounds_played
            ],
        }

    @classmethod
    def from_dict(cls, data: dict) -> Tournament:
        tournament = cls(
            name=data.get("name") or "Турнир",
            rounds=int(data.get("rounds") or 5),
            initial_color=data.get("initial_color") or "white",
            baku=bool(data.get("baku")),
            avoid_same_club=data.get("avoid_same_club", True),
        )
        for raw in data.get("players") or []:
            tournament.players.append(
                Player(
                    name=raw["name"],
                    rating=int(raw.get("rating") or 0),
                    club=raw.get("club") or "",
                    age=clean_age(raw.get("age"), strict=False),
                    sex=clean_sex(raw.get("sex"), strict=False),
                    withdrawn=bool(raw.get("withdrawn")),
                    next_bye=raw.get("next_bye") or "",
                )
            )
        for raw_round in data.get("rounds_played") or []:
            games = [
                Game(white=int(item["white"]), black=item["black"], result=item.get("result"))
                for item in raw_round
            ]
            tournament.rounds_played.append(games)
        return tournament

    def save(self, path: Path) -> None:
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> Tournament:
        return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))


def _game_halves(game: Game, pairing_number: int) -> int:
    if game.result is None:
        return 0
    if game.is_bye:
        if game.white != pairing_number:
            return 0
        return BYE_POINTS[game.result]
    white_result, _black_result, white_halves, black_halves = PLAYED[game.result]
    del white_result
    return white_halves if game.white == pairing_number else black_halves


def _trf_fields(game: Game, pairing_number: int) -> tuple[int, str, str]:
    if game.result is None:
        raise ValueError("Нет результата.")
    if game.is_bye:
        return 0, "-", game.result
    if pairing_number == game.white:
        color = "w"
        result = PLAYED[game.result][0]
        opponent = game.black
    else:
        color = "b"
        result = PLAYED[game.result][1]
        opponent = game.white
    if opponent is None:
        raise ValueError("У партии нет соперника.")
    return opponent, color, result


def round_text(tournament: Tournament, index: int) -> str:
    games = tournament.rounds_played[index]
    lines = [tournament.name, f"Тур {index + 1}", ""]
    board = 1
    byes: list[str] = []
    for game in games:
        if game.is_bye:
            label = BYE_LABELS.get(game.result or "", "бай")
            byes.append(f"{tournament.player(game.white).name} — {label}")
            continue
        assert game.black is not None
        result = RESULT_LABELS.get(game.result or "", "…")
        lines.append(
            f"{board:>2}. {tournament.player(game.white).name} — {tournament.player(game.black).name}    {result}"
        )
        board += 1
    if byes:
        lines.append("")
        lines.extend(byes)
    lines.append("")
    lines.append("Место  №  Игрок                         Очки    Бухг.   Б−1      ЗБ  Поб.")
    for row in tournament.standings():
        lines.append(
            f"{row['place']:>5}  {row['number']:>2}  {row['name'][:28]:<28}  {row['points']:>4.1f}  {row['buchholz']:>7.1f}  {row['buchholz_cut']:>5.1f}  {row['sonneborn']:>6.2f}  {row['wins']:>3}"
        )
    return "\n".join(lines) + "\n"


def self_test() -> None:
    tournament = Tournament(name="Проверка", rounds=5, initial_color="white")
    for name, rating in (
        ("Иванов", 2000),
        ("Petrov", 1900),
        ("Sidorov", 1800),
        ("Kuznetsov", 1700),
        ("Smirnov", 1600),
    ):
        tournament.add_player(name, rating)
    tournament.pair_next_round()
    pairs = [(game.white, game.black or 0) for game in tournament.rounds_played[0]]
    assert pairs == [(1, 3), (4, 2), (5, 0)], pairs
    assert tournament.rounds_played[0][2].result == "U"
    # 1–0, 1–0, бай
    by_white = {game.white: game for game in tournament.rounds_played[0]}
    by_white[1].result = "1-0"
    by_white[4].result = "1-0"
    tournament.player(2).next_bye = "H"
    tournament.pair_next_round()
    second = [(game.white, game.black or 0, game.result) for game in tournament.rounds_played[1]]
    assert (5, 1, None) in second, second
    assert (3, 4, None) in second, second
    assert (2, 0, "H") in second, second
    assert tournament.player(2).next_bye == ""
    assert tournament.points(1) == 1
    assert tournament.points(5) == 1
    assert tournament.points(2) == 0.5
    stored = Tournament.from_dict(tournament.to_dict())
    assert stored.players[0].name == "Иванов"
    aged = Tournament(name="Возраст", rounds=1)
    aged.add_player("Альфа", 1500, "Север", 14, "м")
    assert aged.players[0].age == 14 and aged.players[0].sex == "m"
    assert Tournament.from_dict(aged.to_dict()).players[0].age == 14

    clubs = Tournament(name="Клубы", rounds=3, avoid_same_club=True)
    clubs.add_player("Альфа", 2000, "Север")
    clubs.add_player("Бета", 1900, "Юг")
    clubs.add_player("Гамма", 1800, "Север")
    clubs.add_player("Дельта", 1700, "Юг")
    clubs.pair_next_round()
    for game in clubs.rounds_played[0]:
        if game.black is None:
            continue
        same = clubs.player(game.white).club == clubs.player(game.black).club
        assert not same, (game.white, game.black)
    print("self_test ok")


if __name__ == "__main__":
    self_test()
