"""Командная швейцарка: команды жеребятся голландской системой, внутри матча — доски."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import json

import pairing
from model import BYE_LABELS, PLAYED, RESULT_LABELS, clean_age, clean_sex

BYE_MATCH_POINTS = {"U": 2, "F": 2, "H": 1, "Z": 0}


@dataclass
class Member:
    name: str
    rating: int = 0
    age: int | None = None
    sex: str = ""


@dataclass
class BoardGame:
    white_name: str
    black_name: str
    result: str | None = None


@dataclass
class Match:
    white: int
    black: int | None
    bye: str | None = None
    boards: list[BoardGame] = field(default_factory=list)

    @property
    def is_bye(self) -> bool:
        return self.black is None


@dataclass
class Team:
    name: str
    members: list[Member] = field(default_factory=list)
    withdrawn: bool = False
    next_bye: str = ""

    @property
    def rating(self) -> int:
        return sum(member.rating for member in self.members)


@dataclass
class TeamTournament:
    kind: str = "team"
    name: str = "Командный турнир"
    rounds: int = 5
    boards: int = 4
    initial_color: str = "white"
    baku: bool = False
    teams: list[Team] = field(default_factory=list)
    rounds_played: list[list[Match]] = field(default_factory=list)

    @property
    def started(self) -> bool:
        return bool(self.rounds_played)

    def team(self, number: int) -> Team:
        return self.teams[number - 1]

    def sort_by_rating(self) -> None:
        if self.started:
            raise ValueError("Номера уже присвоены: тур начат.")
        indexed = list(enumerate(self.teams))
        indexed.sort(key=lambda item: (-item[1].rating, item[1].name.casefold(), item[0]))
        self.teams = [team for _, team in indexed]

    def add_team(self, name: str) -> None:
        name = " ".join(name.split())
        if not name:
            raise ValueError("Введите название команды.")
        self.teams.append(Team(name=name))
        number = len(self.teams)
        for matches in self.rounds_played:
            matches.append(Match(white=number, black=None, bye="Z"))

    def remove_team(self, index: int) -> None:
        if self.started:
            raise ValueError("После старта команду можно только снять с жеребьёвки.")
        del self.teams[index]

    def match_points(self, number: int) -> int:
        total = 0
        for matches in self.rounds_played:
            match = _match_of(matches, number)
            if match is None or not _match_ready(match):
                continue
            total += _match_points(match, number)
        return total

    def game_points(self, number: int) -> float:
        total = 0.0
        for matches in self.rounds_played:
            match = _match_of(matches, number)
            if match is None or not _match_ready(match):
                continue
            total += _game_points(match, number, self.boards)
        return total

    def pair_next_round(self) -> list[Match]:
        if len(self.teams) < 2:
            raise ValueError("Нужно хотя бы две команды.")
        if self.boards < 1:
            raise ValueError("Укажите число досок.")
        if len(self.rounds_played) >= self.rounds:
            raise ValueError("Все туры уже сыграны.")
        if self.rounds_played and not self.round_complete(-1):
            raise ValueError("Сначала внесите результаты всех досок.")
        if not self.started:
            self.sort_by_rating()

        round_number = len(self.rounds_played) + 1
        excluded: list[int] = []
        rows: list[str] = []
        for index, team in enumerate(self.teams):
            number = index + 1
            if team.withdrawn or team.next_bye:
                excluded.append(number)
            rows.append(
                pairing.player_line(
                    number,
                    team.name,
                    min(team.rating, 9999),
                    float(self.match_points(number)),
                    self._history(number),
                )
            )
        header = [
            f"012 {self.name}",
            f"XXR {self.rounds}",
            "XXC " + ("white1" if self.initial_color == "white" else "black1"),
            "192 " + ("FIDE_DUTCH_2025_BAKU" if self.baku else "FIDE_DUTCH_2025"),
            "BBW  2.0",
            "BBD  1.0",
            "BBL  0.0",
        ]
        pairs = pairing.pair(header, rows, excluded, round_number)
        matches = self._matches_from_pairs(pairs, excluded)
        self.rounds_played.append(matches)
        for team in self.teams:
            if not team.withdrawn:
                team.next_bye = ""
        return matches

    def delete_last_round(self) -> None:
        if not self.rounds_played:
            raise ValueError("Туров ещё нет.")
        self.rounds_played.pop()

    def round_complete(self, index: int) -> bool:
        return all(_match_ready(match) for match in self.rounds_played[index])

    def _history(self, number: int) -> list[tuple[int, str, str]]:
        history: list[tuple[int, str, str]] = []
        for matches in self.rounds_played:
            match = _match_of(matches, number)
            if match is None or not _match_ready(match):
                raise ValueError("В истории тура есть матч без результата.")
            history.append(_trf_fields(match, number))
        return history

    def _matches_from_pairs(self, pairs: list[tuple[int, int]], excluded: list[int]) -> list[Match]:
        known = set(range(1, len(self.teams) + 1))
        seen: set[int] = set()
        matches: list[Match] = []
        for white, black in pairs:
            if white not in known or (black not in known and black != 0):
                raise pairing.PairingError(f"Движок вернул неизвестный номер: {white} {black}")
            if white in seen or (black and black in seen):
                raise pairing.PairingError("Движок повторил номер команды.")
            seen.add(white)
            if black == 0:
                matches.append(Match(white=white, black=None, bye="U"))
            else:
                seen.add(black)
                matches.append(self._new_match(white, black))
        for number in excluded:
            if number in seen:
                raise pairing.PairingError(f"Команда {number} получила и бай, и матч.")
            team = self.team(number)
            bye = "Z" if team.withdrawn else (team.next_bye or "Z")
            matches.append(Match(white=number, black=None, bye=bye))
            seen.add(number)
        missing = known - seen
        if missing:
            raise pairing.PairingError("Движок вернул неполную жеребьёвку: " + ", ".join(map(str, sorted(missing))))
        return matches

    def _new_match(self, white: int, black: int) -> Match:
        boards: list[BoardGame] = []
        for index in range(self.boards):
            white_team_number = white if index % 2 == 0 else black
            black_team_number = black if index % 2 == 0 else white
            white_name = _member_name(self.team(white_team_number), index)
            black_name = _member_name(self.team(black_team_number), index)
            if white_name and black_name:
                result = None
            elif white_name:
                result = "+-"
            elif black_name:
                result = "-+"
            else:
                result = "--"
            boards.append(BoardGame(white_name=white_name, black_name=black_name, result=result))
        return Match(white=white, black=black, boards=boards)

    def standings(self) -> list[dict]:
        match_points = {number: self.match_points(number) for number in range(1, len(self.teams) + 1)}
        rows = []
        for number, team in enumerate(self.teams, start=1):
            contributions: list[float] = []
            sonneborn = 0.0
            for matches in self.rounds_played:
                match = _match_of(matches, number)
                if match is None or not _match_ready(match):
                    continue
                scored = _match_points(match, number)
                if match.is_bye:
                    contributions.append(float(match_points[number]))
                    continue
                opponent = match.black if match.white == number else match.white
                assert opponent is not None
                contributions.append(float(match_points[opponent]))
                if scored == 2:
                    sonneborn += match_points[opponent]
                elif scored == 1:
                    sonneborn += match_points[opponent] / 2
            buchholz = sum(contributions)
            rows.append(
                {
                    "number": number,
                    "name": team.name,
                    "rating": team.rating,
                    "points": match_points[number],
                    "game_points": self.game_points(number),
                    "buchholz": buchholz,
                    "sonneborn": sonneborn,
                    "withdrawn": team.withdrawn,
                }
            )
        rows.sort(key=lambda row: (-row["points"], -row["game_points"], -row["buchholz"], -row["sonneborn"], row["number"]))
        place = 0
        tie_keys = ("points", "game_points", "buchholz", "sonneborn")
        for index, row in enumerate(rows):
            previous = rows[index - 1] if index else None
            if previous and all(previous[key] == row[key] for key in tie_keys):
                row["place"] = previous["place"]
            else:
                place = index + 1
                row["place"] = place
        return rows

    def export_round(self, index: int) -> str:
        lines = [self.name, f"Тур {index + 1}", ""]
        for match_index, match in enumerate(self.rounds_played[index], start=1):
            if match.is_bye:
                label = BYE_LABELS.get(match.bye or "", "бай")
                lines.append(f"Бай. {self.team(match.white).name} — {label}")
                continue
            assert match.black is not None
            score = _score_text(match, self.boards)
            lines.append(f"Матч {match_index}. {self.team(match.white).name} — {self.team(match.black).name}    {score}")
            for board_index, board in enumerate(match.boards, start=1):
                result = RESULT_LABELS.get(board.result or "", "…")
                white = board.white_name or "без игрока"
                black = board.black_name or "без игрока"
                lines.append(f"    {board_index}. {white} — {black}    {result}")
            lines.append("")
        lines.append("Место  №  Команда                       Матч  Игры    Бухг.     ЗБ")
        for row in self.standings():
            lines.append(
                f"{row['place']:>5}  {row['number']:>2}  {row['name'][:28]:<28}  {row['points']:>4}  {row['game_points']:>5.1f}  {row['buchholz']:>7.1f}  {row['sonneborn']:>6.2f}"
            )
        return "\n".join(lines) + "\n"

    def to_dict(self) -> dict:
        return {
            "kind": "team",
            "name": self.name,
            "rounds": self.rounds,
            "boards": self.boards,
            "initial_color": self.initial_color,
            "baku": self.baku,
            "teams": [
                {
                    "name": team.name,
                    "withdrawn": team.withdrawn,
                    "next_bye": team.next_bye,
                    "members": [
                        {"name": member.name, "rating": member.rating, "age": member.age, "sex": member.sex}
                        for member in team.members
                    ],
                }
                for team in self.teams
            ],
            "rounds_played": [
                [
                    {
                        "white": match.white,
                        "black": match.black,
                        "bye": match.bye,
                        "boards": [
                            {"white_name": board.white_name, "black_name": board.black_name, "result": board.result}
                            for board in match.boards
                        ],
                    }
                    for match in matches
                ]
                for matches in self.rounds_played
            ],
        }

    @classmethod
    def from_dict(cls, data: dict) -> TeamTournament:
        tournament = cls(
            name=data.get("name") or "Командный турнир",
            rounds=int(data.get("rounds") or 5),
            boards=int(data.get("boards") or 4),
            initial_color=data.get("initial_color") or "white",
            baku=bool(data.get("baku")),
        )
        for raw in data.get("teams") or []:
            team = Team(
                name=raw["name"],
                withdrawn=bool(raw.get("withdrawn")),
                next_bye=raw.get("next_bye") or "",
            )
            for member in raw.get("members") or []:
                team.members.append(
                    Member(
                        name=member["name"],
                        rating=int(member.get("rating") or 0),
                        age=clean_age(member.get("age"), strict=False),
                        sex=clean_sex(member.get("sex"), strict=False),
                    )
                )
            tournament.teams.append(team)
        for raw_round in data.get("rounds_played") or []:
            matches = []
            for item in raw_round:
                match = Match(white=int(item["white"]), black=item.get("black"), bye=item.get("bye"))
                for board in item.get("boards") or []:
                    match.boards.append(
                        BoardGame(
                            white_name=board.get("white_name") or "",
                            black_name=board.get("black_name") or "",
                            result=board.get("result"),
                        )
                    )
                matches.append(match)
            tournament.rounds_played.append(matches)
        return tournament

    def save(self, path: Path) -> None:
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def _member_name(team: Team, index: int) -> str:
    if index >= len(team.members):
        return ""
    return team.members[index].name.strip()


def _match_of(matches: list[Match], number: int) -> Match | None:
    return next((match for match in matches if match.white == number or match.black == number), None)


def _match_ready(match: Match) -> bool:
    if match.is_bye:
        return bool(match.bye)
    return all(board.result for board in match.boards)


def _game_points(match: Match, number: int, boards: int) -> float:
    if match.is_bye:
        if match.white != number:
            return 0.0
        if match.bye in {"U", "F"}:
            return boards / 2
        if match.bye == "H":
            return boards / 4
        return 0.0
    total = 0
    for index, board in enumerate(match.boards):
        if not board.result:
            continue
        team_is_white = (index % 2 == 0 and match.white == number) or (index % 2 == 1 and match.black == number)
        halves = PLAYED[board.result][2 if team_is_white else 3]
        total += halves
    return total / 2


def _match_points(match: Match, number: int) -> int:
    if match.is_bye:
        if match.white != number:
            return 0
        return BYE_MATCH_POINTS[match.bye or "Z"]
    assert match.black is not None
    white_points = _game_points(match, match.white, len(match.boards))
    black_points = _game_points(match, match.black, len(match.boards))
    if white_points > black_points:
        return 2 if number == match.white else 0
    if white_points < black_points:
        return 0 if number == match.white else 2
    return 1


def _trf_fields(match: Match, number: int) -> tuple[int, str, str]:
    if match.is_bye:
        return 0, "-", match.bye or "Z"
    assert match.black is not None
    scored = _match_points(match, number)
    result = {2: "1", 1: "=", 0: "0"}[scored]
    if number == match.white:
        return match.black, "w", result
    return match.white, "b", result


def _score_text(match: Match, boards: int) -> str:
    if not _match_ready(match) or match.black is None:
        return "…"
    white = _game_points(match, match.white, boards)
    black = _game_points(match, match.black, boards)
    return f"{_trim(white)}–{_trim(black)}"


def _trim(value: float) -> str:
    return f"{value:.1f}".rstrip("0").rstrip(".")


def self_test() -> None:
    tournament = TeamTournament(name="Команды", rounds=3, boards=2)
    roster = [
        ("Север", [("Иванов", 2000), ("Петров", 1800)]),
        ("Юг", [("Сидоров", 1900), ("Кузнецов", 1700)]),
        ("Запад", [("Смирнов", 1600), ("Орлов", 1500)]),
        ("Восток", [("Волков", 1400), ("Зайцев", 1300)]),
        ("Центр", [("Морозов", 1200), ("Новиков", 1100)]),
    ]
    for name, members in roster:
        tournament.add_team(name)
        for member_name, rating in members:
            tournament.teams[-1].members.append(Member(member_name, rating))
    tournament.pair_next_round()
    pairs = [(match.white, match.black or 0) for match in tournament.rounds_played[0]]
    assert pairs == [(1, 3), (4, 2), (5, 0)], pairs
    assert tournament.rounds_played[0][-1].bye == "U"
    for match in tournament.rounds_played[0]:
        if match.is_bye:
            continue
        match.boards[0].result = "1-0"
        match.boards[1].result = "0-1"
    assert tournament.match_points(1) == 2
    assert tournament.game_points(1) == 2.0
    assert tournament.game_points(5) == 1.0
    tournament.pair_next_round()
    assert tournament.round_complete(0)
    tournament.teams[0].members[0].age = 11
    tournament.teams[0].members[0].sex = "f"
    restored = TeamTournament.from_dict(tournament.to_dict())
    assert restored.teams[0].members[0].age == 11
    assert restored.teams[0].members[0].sex == "f"
    print("team self_test ok")


if __name__ == "__main__":
    self_test()
